//
//  Constructor.swift
//  Constructor
//
//  Created by Wilf Lalonde on 2023-01-24.
//

import Foundation

typealias treeClosure = (VirtualTree) -> Any //Ultimately FSM

public final class Constructor : Translator {
    var debug = true
    var parser: Parser?
    var tree: VirtualTree? = nil
    var fsmMap: Dictionary<String,Any> = [:] //Ultimately FSM
    var readaheadStates: [ReadaheadState] = []
    var readbackStates: [ReadbackState] = []
    var reduceStates: Dictionary<String, ReduceState> = [:] // key is a nonterminal
    var semanticStates: [SemanticState] = []
    var acceptState: AcceptState?
    var right: Relation<FiniteStateMachineState, Label>?
    var down: Relation<FiniteStateMachineState, String>?
    var left: Relation<Pairing, Pairing>?
    var up: Relation<Pairing, String>?
    var invisibleLeft: Relation<Pairing, Pairing>?
    var visibleLeft: Relation<Pairing, Pairing>?
    
    init() {
        parser = Parser(sponsor: self, parserTables: parserTables, scannerTables: scannerTables)
    }
    
    func process (_ text: String) -> Void {
        if let tree = parser!.parse(text) as? Tree {
            print("tree from parser:")
            print(tree)
            _ = walkTree(tree)
        } else {
            print("Failed to parse the text into a Tree")
        }
    }
    
    func renumber () {
        var count = 1
        Grammar.activeGrammar?.renumber()
        
        for raState in readaheadStates {
            raState.stateNumber = count
            count += 1
        }
        for rbState in readbackStates {
            rbState.stateNumber = count
            count += 1
        }
        for s in semanticStates {
            s.stateNumber = count
            count += 1
        }
        for reduceState in reduceStates.values {
            reduceState.stateNumber = count
            count += 1
        }
        acceptState?.stateNumber = count
    }
    
    func walkTree (_ tree: VirtualTree) -> Any {
        let action = tree.label as String
        switch (action) {
        case "walkList":
            return walkList (tree)
        case "walkCharacter":
            return walkCharacter (tree)
        case "walkString":
            return walkString (tree)
        case "walkIdentifier":
            return walkIdentifier(tree)
        case "walkSymbol":
            return walkSymbol (tree)
        case "walkInteger":
            return walkInteger (tree)
        case "walkAttributes":
            return walkAttributes (tree)
        case "walkBuildTreeOrTokenFromName":
            return walkbuildTreeOrTokenFromName (tree)
        case "walkbuildTreeFromRightIndex":
            return walkbuildTreeFromRightIndex (tree)
        case "walkBuildTreeFromLeftIndex":
            return walkBuildTreeFromLeftIndex (tree)
        case "walkTreeBuildingSemanticAction":
            return walkTreeBuildingSemanticAction (tree)
        case "walkNonTreeBuildingSemanticAction":
            return walkNonTreeBuildingSemanticAction (tree)
        case "walkLook":
            return walkLook (tree)
        case "walkPlus":
            return walkPlus (tree)
        case "walkEpsilon":
            return walkEpsilon (tree)
        case "walkQuestionMark":
            return walkQuestionMark (tree)
        case "walkStar":
            return walkStar (tree)
        case "walkOr":
            return walkOr (tree)
        case "walkConcatenation":
            return walkConcatentation (tree)
        case "walkAnd":
            return walkAnd (tree)
        case "walkMinus":
            return walkMinus (tree)
        case "walkDotDot":
            return walkDotDot (tree)
        case "walkGrammar":
            return walkGrammar(tree)
        case "walkProduction":
            return walkProduction(tree)
        case "walkLeftPartWithLookahead":
            return walkLeftPartWithLookahead(tree)
        case "walkLeftPart":
            return walkLeftPart(tree)
        case "walkMacro":
            return walkMacro(tree)
        case "walkAttributeDefaults":
            return walkAttributeDefaults(tree)
        case "walkKeywords":
            return walkKeywords(tree)
        case "walkOutput":
            return walkOutput(tree)
        default:
            error ("Attempt to perform unknown walkTree routine \(action)")
            return 0
        }
    }
    
  public func canPerformAction(_ action: String) -> Bool {
      if (action == "processTypeNow") {return true;}
      if (action == "processAndDiscardDefaultsNow") {return true}
      return false
    }
          
  public func performAction(_ action :String, _ parameters:[Any]) -> Void {
      if (action == "processTypeNow") {
          processTypeNow (parameters)
      }
      if (action == "processAndDiscardDefaultsNow") {
          processAndDiscardDefaultsNow()
      }
  }
    
    static public func example () -> String {
        let grammar = Grammar  ()
        Grammar.activeGrammar = grammar
        
        let exampleFiles: [Int: String] = [
            0: "toyLispGrammar",
            1: "toyScannerGrammar",
            2: "toyParserGrammarWithMacros",
            3: "toyArithmeticExpressionGrammar Version 1",
            4: "toyArithmeticExpressionGrammar Version 2",
            5: "toyParserGrammarLeftRecursive",
            6: "toyParserGrammarRightRecursive",
            7: "toyParserGrammarNonRecursive",
            8: "toyParserGrammarToTestFollowSets",
            9: "LISPGrammarWithInvisibles",
            10: "parserGrammar",
            11: "realParserGrammar"
        ]
        
        let numberToTest = 11
        let fileName = exampleFiles[numberToTest]
        var fileContent = ""

        if let filePath = Bundle.main.path(forResource: fileName, ofType: "txt") {
            let fileURL = URL(fileURLWithPath: filePath)
            do {
                fileContent = try String(contentsOf: fileURL, encoding: .utf8)
            } catch {
                print("Error reading the file: \(error)")
            }
        } else {
            print("File not found in the app bundle.")
        }
        
        let builder = Constructor ();
        builder.process (fileContent)
        builder.createTables()
        return "Done"
    }
    
    
    func createTables() {
        guard let grammar = Grammar.activeGrammar else {
            return
        }
        
        // create reduce and accept state(s) for parser
        if grammar.isParser() {
            // create reduce states and accept state
            for nonterminal in grammar.nonterminals {
                if nonterminal.contains("'") {
                    acceptState = AcceptState()
                } else {
                    let reduceState = ReduceState()
                    reduceState.nonterminal = nonterminal
                    reduceStates[nonterminal] = reduceState
                }
            }
            renumber()
        }
        
        // create the right and down relations from the grammar's productions
        self.createRightAndDownRelations()
        
        // build our ra states and semantic states
        self.buildReadaheadStates()
        self.attachReadaheadFollowSets()
        self.buildSemanticStates()
        
        // split the left relation into invisible/visible relations
        self.splitLeftRelation()
        
        // for scanners, bridge readaheads back to the initial ra state
        // for parers, we have reduce/readback tables
        if grammar.isScanner() {
            self.buildScannerBridges()
        } else {
            // alternates for reduce tables
            self.finalizeReadaheadAndReduceStates()
            self.buildAlternateRestarts()
            
            // build readback state bridges - not needed for scanners
            self.buildReadbackStateBridges()
            self.finishReadbackStates()
        }
        
        self.checkConflicts()
        self.replaceReadbackWithShift()
        
        if grammar.isScanner() {
            printScannerTables()
        } else {
            printParserTables()
            self.outputTablesToFile()
        }
    }
    
    
    func replaceReadbackWithShift() {
        
    }
    
    
    func outputTablesToFile() {
        var outputFile: FileHandle?
        let fileName = "output.txt"
        open(&outputFile, fileName)
        
        // keywords
        let keywords = Grammar.activeGrammar!.keywords
        let keywordsLine = "[\"keywords\", " + keywords.map { "\"\($0)\"" }.joined(separator: ", ") + "],"
        write(&outputFile, keywordsLine + "\n")
        
        // Parer Readahead tables
        var raTableLines: [String] = []
        for raState in readaheadStates {
            raTableLines.append(raState.getFormattedParserTable())
        }
        
        for line in raTableLines {
            print(line)
            write(&outputFile, line)
        }
        
        // Readback tables
        var rbTableLines: [String] = []
        for rbState in readbackStates {
            rbTableLines.append(rbState.getFormmatedTableLine())
        }
        
        for line in rbTableLines {
            print(line)
            write(&outputFile, line)
        }
        
        // Reduce tables
        var reduceTableLines: [String] = []
        for redState in reduceStates.values {
            reduceTableLines.append(redState.getFormmatedTableLine())
        }
        
        for line in reduceTableLines {
            print(line)
            write(&outputFile, line)
        }
        
        // Semantic Tables
        var semTableLines: [String] = []
        for st in semanticStates {
            semTableLines.append(st.getFormmatedTableLine())
        }
        
        for line in semTableLines {
            print(line)
            write(&outputFile, line)
        }
        
        // Accept Table
        let acceptLine = "[\"AcceptTable\", \(acceptState!.stateNumber)]"
        write(&outputFile, acceptLine + "]")
        close(&outputFile)
    }
    
    
    func checkConflicts() {
        print("Checking attribute conflicts...")
        // Attribute conflicts
        // go thru readahead states transitions and partition by label name, if partition has >1 entry for the RA state, there's a conflict
        for raState in readaheadStates {
            // group transitions by label name
            let partition = Dictionary(grouping: raState.transitions, by: { $0.label!.name })
            
            for (labelName, transitions) in partition {
                if transitions.count > 1 {
                    print("Conflict detected in readahead state \(raState.stateNumber) for label: \(labelName) with transitions: \(transitions)")
                }
            }
        }
        
        print("Checking restart conflicts...")
        // reduce alternate conflicts (parsers)
        // partition reduce state's restarts by 'from' state numbers --> should only be one entry per reduce state
        for (_, reduceState) in reduceStates {
            let partition = Dictionary(grouping: reduceState.restarts) { $0.0.stateNumber }
            for (stateNumber, entries) in partition {
                if entries.count > 1 {
                    print("Conflict detected in reduce state for state number: \(stateNumber) with entries: \(entries)")
                }
            }
        }
    }
    
    
    func createRightAndDownRelations() {
        guard let grammar = Grammar.activeGrammar else {
            return
        }
        
        right = Relation()
        grammar.allRightTriplesDo { (state, transitionLabel, goto) in
            right!.add(from: state, relationship: transitionLabel, to: goto)
        }
        
        down = Relation()
        grammar.allDownTriplesDo { (state, nonterminal, initialState) in
            down!.add(from: state, relationship: nonterminal, to: initialState)
        }
    }
    
    
    func buildReadaheadStates () {
        self.up = Relation ()
        self.left = Relation ()
        
        for goalProduction in Grammar.activeGrammar!.goalProductions() {
            let readaheadState = ReadaheadState()
            readaheadState.initialItems = goalProduction.fsm.getInitialStates()
            readaheadStates.append(readaheadState)
        }
        renumber()
        
        var index = 0
        while index < readaheadStates.count {
            let raState = readaheadStates[index]
            let localDown = down?.performRelationStar(items: raState.initialItems)
            
            for triple in localDown!.triples {
                let relationship = triple.relationship
                let firstPairing = Pairing(triple.to, raState)
                let secondPairing = Pairing(triple.from, raState)
                up?.add(Triple(from: firstPairing, relationship: relationship, to: secondPairing))
            }
            
            // compute successors
            raState.finalItems = raState.initialItems + localDown!.allTo()
            
            right?.from(raState.finalItems) { (relationship: Label, localRight: Relation<FiniteStateMachineState, Label>) in
                let candidateItems = localRight.allTo()
                let candidate = ReadaheadState()
                candidate.initialItems = candidateItems
                
                // Match candidate with existing readahead states
                var successor = self.match(candidate, readaheadStates)
                if successor == nil {
                    readaheadStates.append(candidate)
                    successor = candidate
                    renumber() // renumber for new RA state
                }
                
                raState.transitions.append(Transition(relationship, successor!))
                
                for triple in localRight.triples {
                    let labelPairing = Pairing(triple.relationship, successor! as ReadaheadState)
                    let pairing1 = Pairing(triple.to, successor! as ReadaheadState)
                    let pairing2 = Pairing(triple.from, raState)
                    left?.add(Triple(from: pairing1, relationship: labelPairing, to: pairing2))
                }
            }
            
            index += 1
        }
    }
    
    func attachReadaheadFollowSets () {
        // iterate over readaheads, find all semantic transitions
        // for every semantic transiton, compute the followset of the goto (a ra state) and attach it to it
        for raState in readaheadStates {
            raState.transitionsDo { transition in
                if transition.label?.hasAction() == true { // Semantic transition
                    let goto = transition.goto as! ReadaheadState
                    goto.follow = Grammar.activeGrammar?.computeReadaheadFollowSet(raState: goto) ?? []
                }
            }
        }
    }
    
    func buildSemanticStates () {
        /* for every semantic transiiton, build a semantic state where the label is the semantic
           transition label and the goto is the original transition's goto state
           set the goto of the 'from' readahead state to the semantic state
         */
        for raState in readaheadStates {
            var transitionsToRemove: [Transition] = []

            raState.transitionsDo { transition in
                if transition.label?.hasAction() == true { // Semantic transition
                    let semState = SemanticState(transition.label!, transition.goto!)
                    if let gotoFollowSet = Grammar.activeGrammar?.computeReadaheadFollowSet(raState: transition.goto as! ReadaheadState) {
                        for lookahead in gotoFollowSet {
                            raState.transitions.append(Transition(Label(lookahead, AttributeList().set(Grammar.lookDefaults())), semState))
                        }
                        transitionsToRemove.append(transition)
                    }
                    semanticStates.append(semState)
                }
            }
            
            // remove the old semantic transitions
            for transition in transitionsToRemove {
                if let index = raState.transitions.firstIndex(where: { $0 === transition }) {
                    raState.transitions.remove(at: index)
                }
            }
        }
        
    }
    
    
    // bridge lookahead transition back to the initial readahead state (instead of to an initial readback state).
    func buildScannerBridges() {
        for raState in readaheadStates {
            let finalItems = raState.finalItems.filter({ $0.isFinal })
            let partition = Dictionary(grouping: finalItems, by: { $0.leftPart })
            
            for (nonterminal, _) in partition {
                if let production = Grammar.activeGrammar?.productions[nonterminal] {
                    let followSet = production.followSet
                    for lookahead in followSet {
                        raState.transitions.append(Transition(Label(lookahead, AttributeList().set(Grammar.lookDefaults())), raState))
                    }
                }
            }
        }
    }
    
    
    func buildReadbackStateBridges() {
        readbackStates = []
        
        for raState in readaheadStates {
            let finalStates = raState.finalItems.filter({ $0.isFinal })
            let partition = Dictionary(grouping: finalStates, by: { $0.leftPart })
            
            for (nonterminal, finalStates) in partition {
                var newReadbackState:ReadbackState
                
                if let production = Grammar.activeGrammar?.productions[nonterminal] {
                    if production.isGoal() {
                        acceptState = AcceptState()
                    } else {
                        newReadbackState = ReadbackState()
                        let finalStatePairs = finalStates.map { finalState in
                            return Pairing(finalState, raState)
                        }
                        newReadbackState.initialItems = finalStatePairs
                        readbackStates.append(newReadbackState)
                        
                        // make transitions from the readahead state to the readback state, using the followset of the nonterminal's production as look labels
                        let followSet = production.followSet
                        for lookahead in followSet {
                            raState.transitions.append(Transition(Label(lookahead, AttributeList().set(Grammar.lookDefaults())), newReadbackState))
                        }
                    }
                    
                    renumber()
                }
            }
        }
    }
    
    func finishReadbackStates() {
        var index = 0
                
        while index < readbackStates.count {
            let rbState = readbackStates[index]
            let moreItems: [Pairing] = (invisibleLeft?.performStar(items: rbState.initialItems))!
            rbState.finalItems = moreItems

            // go over visible left relation from the items/finalItems in the current readback
            // get all the 'to' states for the localLeft relation and add them to the initial items of the candidate readback state
            // check if that readback state exists already
            visibleLeft!.from(rbState.finalItems) { (relationship: Pairing, localLeft: Relation<Pairing, Pairing>) in
                let candidate = ReadbackState()
                let candidateItems = localLeft.allTo()
                candidate.initialItems = candidateItems
                
                // Match candidate with existing readahead states
                var successor = self.match(candidate, readbackStates)
                if successor == nil {
                    readbackStates.append(candidate)
                    successor = candidate
                    renumber()
                }
                
                // add transition to successor
                rbState.transitions.append(Transition(relationship, successor!)) // label pair
            }
            
            let initialStateItems: [Pairing] = rbState.finalItems.filter{($0.isInitial())} // might be empty
            
            // item1 in rb state items is a right part state, who's left part is a non terminal
            // initialStateItems here is a Pairing of right part states and their readahead state gotos
            if !initialStateItems.isEmpty {
                // get lookbacks for the initial state pairings 
                let lookbacks = lookbackFor(initialStateItems)
                
                for lookback in lookbacks {
                    if let initialState = initialStateItems.first?.item1 as? FiniteStateMachineState {
                        let reduceStateNonTerminal = initialState.leftPart
                        if let reduceState = reduceStates[reduceStateNonTerminal] {
                            let lookbackAsLook = lookback.asLook()
                            rbState.transitions.append(Transition(lookbackAsLook, reduceState))
                        }
                    }
                }
                
            }
            
            index += 1
        }
    }
    
    // Receives a collection of pairings, where item1 is an initial right part state and item2 is a readahead state
    // lookbackFor should return a pairing of labels and right part states
    func lookbackFor(_ items: [Pairing]) -> [Pairing]{
        var result: [Pairing] = []
        
        if let singleUpItems = up?.performOnce(items: items) {
            result.append(contentsOf: singleUpItems)
        }

        // make a new collection from the result, process items in newItems whie
        var newItems: [Pairing] = result
        var additionalItems: [Pairing] = []
        
        // Continue processing while there are new items to evaluate
        while !newItems.isEmpty {
            // Clear additionalItems to store new findings in this iteration
            additionalItems.removeAll()
            
            for item in newItems {
                // Get 'tos' pairings from 'up' relation based on the current item pairing, add any new items found to additionalItems collection
                if let upItems = up?.performStar(items: [item]) {
                    additionalItems.append(contentsOf: upItems.filter { !result.contains($0) && !additionalItems.contains($0) })
                }
                // Get 'tos' pairings from 'left' relation based on the current item pairing, add any new items found to additionalItems collection
                if let leftItems = invisibleLeft?.performStar(items: [item]) {
                    additionalItems.append(contentsOf: leftItems.filter { !result.contains($0) && !additionalItems.contains($0) })
                }
            }
            
            // If we found new items, add them to result and continue the loop
            if !additionalItems.isEmpty {
                result.append(contentsOf: additionalItems)
                newItems = additionalItems
            } else {
                break
            }
        }
        
        // visible left is a relation where pairs of right part states and ra states are connected by a label pair,
        var lookbacks: [Pairing] = []
        visibleLeft!.from(result) { (relationship: Pairing, relation: Relation<Pairing, Pairing>) in
            // relationship is a label pair b/w the label and the readahead 
            let lookback = relationship.asLook()

            // Check if the lookback already exists in the lookbacks array
            if !lookbacks.contains(where: {
                if let label1 = $0.item1 as? Label, let label2 = lookback.item1 as? Label {
                    if label1 == label2 {
                        if let state1 = $0.item2 as? FiniteStateMachineState, let state2 = lookback.item2 as? FiniteStateMachineState {
                            return state1.stateNumber == state2.stateNumber
                        }
                    }
                }
                return false
            }) {
                lookbacks.append(lookback)
            }
        }
        
        return lookbacks
    }
    
    
    func finalizeReadaheadAndReduceStates() {
        // move all ra state nonterminal transitions into the appropriate reduce state as an array of triples where the from is an integer w/ the original ra state state number
        for raState in readaheadStates {
            raState.transitionsDo { transition in
                if Grammar.activeGrammar?.isNonterminal(transition.label!.name) == true {
                    if let reduceState = reduceStates[transition.label!.name] {
                        let transitionAttrributes = transition.label?.attributes.description
                        reduceState.reduceTransitions.append(Triple(from: raState, relationship: transitionAttrributes!, to: transition.goto! as! ReadaheadState))
//                        reduceState.reduceTransitions.append(Triple(from: raState.stateNumber, relationship: transitionAttrributes!, to: transition.goto?.stateNumber))
                    }
                }
            }
        }
    }
    
    
    // get the nonterminal transitions of readahead states, make a reduce triple (tuple) and get the alternates for it
    // then for each alternate readahead state found, add it with the attributes and goto readahead to the restarts of the
    // corresponding reduce state for that non terminal
    func buildAlternateRestarts() {
        for raState in readaheadStates {
            for transition in raState.transitions {
                let label = transition.label
                if Grammar.activeGrammar?.isNonterminal(label!.name) == true {
                    let gotoReadahead = transition.goto as! ReadaheadState
                    let nonterm = label?.name
                    let reduceTuple = (first: raState, second: label!, third: gotoReadahead)
                    let alternates = alternateRestartsFor(reduceTuple)
                    let reduceState = reduceStates[nonterm!]
                    
                    for alternate in alternates {
                        let combination: (ReadaheadState, String, ReadaheadState) = (alternate, label!.attributes.description, gotoReadahead)
                        reduceState?.addRestartsIfAbsent(combination)
                    }
                }
            }
        }
        // add original restarts to alternate restarts (should be no duplicates)
        for reduceState in reduceStates.values {
            for triple in reduceState.reduceTransitions {
                // add to restarts if there's not already a triple in reduceState.restarts where the first object is the same RA state as the from in the triple
                let raState = triple.from
                let label = triple.relationship
                let goto = triple.to
                let combo = (raState, label, goto)
                reduceState.addRestartsIfAbsent(combo)
            }
        }
    }
    
    
    func alternateRestartsFor(_ reduceTuple: (first: ReadaheadState, second: Label, third: ReadaheadState)) -> [ReadaheadState] {
        let from = reduceTuple.first
        let label = reduceTuple.second
        let to = reduceTuple.third
        
        let candidates = visibleLeft!.triples.filter({ triple in
            let a = triple.from
            let b = triple.relationship
            let c = triple.to
            
            return a.item2 as! ReadaheadState == to && b.item1 as! Label == label && c.item2 as! ReadaheadState == from
        })
        
        let pairs = candidates.map({ $0.to })
        var result: Set<Pairing> = Set(pairs)
        
        for item in result {
            let upItems = up?.performStar(items: [item])
            let leftItems = invisibleLeft?.performStar(items: [item])
            result.formUnion(upItems!)
            result.formUnion(leftItems!)
        }
        
        let resultArray = Array(result)
        
        var alternateRestarts: [ReadaheadState] = []
        visibleLeft!.from(resultArray, relationsDo: { (relationship: Pairing, relation: Relation<Pairing, Pairing>) in
            alternateRestarts.appendIfAbsent(relationship.item2 as! ReadaheadState)
        })
        return alternateRestarts
    }

    
    // tells you the kind of fsm you're building
    func processTypeNow (_ parameters:[Any]) -> Void {
        let type = parameters [0] as? String;
        Grammar.activeGrammar?.type = type!
    }
    
    func printParserTables() {
        print("\nReadahead Tables\n")
        for raState in readaheadStates {
            raState.printOn()
            print("\n")
        }
        
        if (Grammar.activeGrammar?.isParser() == true) {
            print("\nReadback Tables\n")
            for rbState in readbackStates {
                rbState.printOn()
            }
        }
        
        print("\nReduce Tables\n")
        for redState in reduceStates.values {
            redState.printOn()
        }
        
        print("\nSemantic Tables\n")
        for semState in semanticStates {
            semState.printOn()
        }
        
        print("\nAccept Table\n")
        acceptState?.printOn()
    }
    
    func printScannerTables() {
        print("\nReadahead States\n")
        for raState in readaheadStates {
            raState.printOn()
            print("\n")
        }
        
        if (Grammar.activeGrammar?.isParser() == true) {
            print("\nReadback States\n")
            for rbState in readbackStates {
                rbState.printOn()
            }
        }
        
        print("\nReduce States\n")
        for redState in reduceStates.values {
            redState.printOn()
        }
        
        print("\nSemantic States\n")
        for semState in semanticStates {
            semState.printOn()
        }
        
        // if parser, print readback/reduce/accept
    }

    
    func splitLeftRelation() {
        let visibleTriples = left!.triples.filter { $0.relationship.isVisible() }
        visibleLeft = Relation(triples: Set(visibleTriples))
        
        let invisibleTriples = left!.triples.filter { !$0.relationship.isVisible() }
        invisibleLeft = Relation(triples: Set(invisibleTriples))
    }
    
    func match(_ candidate: ReadaheadState, _ readaheadStates: [ReadaheadState]) -> ReadaheadState? {
        for state in readaheadStates {
            if state.initialItems == candidate.initialItems {
                return state
            }
        }
        return nil  
    }
    
    func match(_ candidate: ReadbackState, _ readbackStates: [ReadbackState]) -> ReadbackState? {
        for state in readbackStates {
            if state.initialItems == candidate.initialItems {
                return state
            }
        }
        return nil
    }
    
    func walkGrammar (_ tree: VirtualTree) {
        guard let tree = tree as? Tree else {
            print("Error: Expected tree to be of type Tree, but it's not.")
            return
        }
        // do the first pass
        firstPassWalkTree(tree)
        
        // now process the tree
        for child in tree.children {
            _ = walkTree(child)
        }
        
        Grammar.activeGrammar?.finalize()
        Grammar.activeGrammar?.renumber()
        
        if let description = Grammar.activeGrammar?.description {
            print(description)
        }
    }
    
    func firstPassWalkTree(_ tree: VirtualTree) {
        // first pass should identify nonterminals
        if let tree = (tree as? Tree) {            
            if tree.label == "walkLeftPartWithLookahead" || tree.label == "walkLeftPart" {
                if let firstChild = (tree.children.first as? Token) {
                    Grammar.activeGrammar?.nonterminals.append(firstChild.symbol)
                }
                return
            }
            
            for child in tree.children {
                firstPassWalkTree(child)
            }
            
        } else {
            return
        }
    }
      
    func walkList (_ tree: VirtualTree) -> Any {
        let treeList = (tree as? Tree)!
        var index = 0;
        while (index < treeList.children.count) {
            let child0 = treeList.children[index]
            let child1 = treeList.children[index+1]

            let name = (child0 as? Token)!.symbol
            let fsm = walkTree (child1)

            fsmMap [name] = fsm
            Grammar.activeGrammar!.addMacro (name, fsm as! FiniteStateMachine)
            index += 2;
        }
        return 0
    }
    
    // for printing the fsm nice like
    func printOn (fsmMap: Dictionary<String,Any>) {
        let sortedDict = fsmMap.sorted { (item1, item2) -> Bool in
            let number1 = extractNumber(from: item1.key)
            let number2 = extractNumber(from: item2.key)

            return number1 < number2
        }

        for (key, value) in sortedDict {
            if let fsm = value as? FiniteStateMachine {
                print(key)
                fsm.printOn()
                print()
            }
        }
    }
    
    // builds the production and stores it in Grammar.productions
    func walkProduction(_ tree : VirtualTree) -> Any {
        guard let tree = tree as? Tree else {
            print("Error: Expected tree to be of type Tree, but it's not.")
            return 0
        }
        
        let production = Production()
        let result = walkTree(tree.children[0])
        var nonterminalSymbol = ""
        
        switch result {
            case let tuple as (String, [String]):  // nonterminal and lookahead collection
                nonterminalSymbol = tuple.0
                production.lookahead = tuple.1
            case let nonterminal as String:  // Just a String
                nonterminalSymbol = nonterminal
            default:
                print("Unexpected result format for Production.")
                return 0
        }
        
        production.leftPart = nonterminalSymbol
        
        // get right part/FSM
        let fsm = walkTree(tree.children[1]) as! FiniteStateMachine
        production.fsm = fsm
        Grammar.activeGrammar?.productions[nonterminalSymbol] = production
        return production
    }
    
    func walkMacro(_ tree : VirtualTree) -> Any {
        // first child is a token, symbol is the name for the macro
        // second child might be a tree or a token/it's an FSM, so walkTree on that child and then add the macro/fsm
        guard let tree = tree as? Tree else {
            print("Error: Expected tree to be of type Tree, but it's not.")
            return 0
        }
        
        let child0 = tree.children[0] as! Token
        let name = child0.symbol
        
        let fsm = walkTree(tree.children[1]) as? FiniteStateMachine
        Grammar.activeGrammar?.addMacro(name, fsm!)
        return 0
    }
    
    func walkLeftPartWithLookahead(_ tree : VirtualTree) -> Any {
        guard let tree = tree as? Tree else {
            print("Error: Expected tree to be of type Tree, but it's not.")
            return 0
        }
        
        // first child is nonterminal
        let child0 = tree.children[0] as! Token
        let nonterminal = child0.symbol
        
        // second child is lookahead fsm, but it needs to go to walkTree
        let child1 = tree.children[1]
        let lookaheadFSM = walkTree(child1) as! FiniteStateMachine
        
        // get transitions from lookahead FSM
        var lookaheadSymbols: [String] = []
        lookaheadFSM.transitionsDo { (transition: Transition) in
            if !transition.label!.hasAction() {
                lookaheadSymbols.append(transition.label!.name)
            }
        }
        
        print("LOOKAHEAD SYMBOLS: \(lookaheadSymbols)")
    
        return (nonterminal, lookaheadSymbols)
    }
    
    func walkLeftPart(_ tree : VirtualTree) -> Any {
        guard let tree = tree as? Tree else {
            print("Error: Expected tree to be of type Tree, but it's not.")
            return 0
        }
            
        // first child is nonterminal
        let child0 = tree.children[0] as! Token
        return child0.symbol
    }
    
    // Helper function to extract the numeric part from FSM name
    func extractNumber(from string: String) -> Int {
        // Use a regular expression to find the numeric part of the string
        if let match = string.range(of: "\\d+", options: .regularExpression) {
            let numberString = string[match]
            return Int(numberString) ?? 0 // Default to 0 if no number is found
        }
        return 0
    }
    
    func walkKeywords (_ tree: VirtualTree) {
//        "Note: This walk routine is initiated by #processAndDiscardDefaultsNow which subsequently
        //All it does is give the grammar the keywords and prints them..."
        if let tree = tree as? Tree {
            let keywords = tree.children.compactMap { ($0 as? Token)?.symbol }
            Grammar.activeGrammar?.keywords = keywords
        }
     }
    
    // create an empty FSM
    func walkEpsilon (_ tree : VirtualTree) -> Any {
        return FiniteStateMachine.empty()
    }
    
    func walkCharacter (_ tree : VirtualTree) -> Any {
        let token = tree as! Token
        return FiniteStateMachine.forCharacter(token.symbol)
    }
    
    func walkPlus (_ tree : VirtualTree) -> Any {
        guard let tree = tree as? Tree else {
            print("Error: Expected tree to be of type Tree, but it's not.")
            return 0
        }
        // should build an fsm with +
        let child = tree.children[0]
        let fsm = walkTree(child) as? FiniteStateMachine
        return fsm!.plus()
    }
    
    func walkQuestionMark (_ tree : VirtualTree) -> Any {
        guard let tree = tree as? Tree else {
            print("Error: Expected tree to be of type Tree, but it's not.")
            return 0
        }
        let child = tree.children[0]
        let fsm = walkTree(child) as? FiniteStateMachine
        return fsm?.or(otherFSM: FiniteStateMachine.empty()) as Any
    }
    
    func walkStar (_ tree : VirtualTree) -> Any {
        guard let child = extractFirstChild(tree) else {
            print("No child found")
            return 0
        }
        
        if let fsm = walkTree(child) as? FiniteStateMachine {
            return fsm.plus().or(otherFSM: FiniteStateMachine.empty())
        } else {
            print("walkTree did not return a FiniteStateMachine")
            return 0
        }
    }
    
    func walkDotDot (_ tree : VirtualTree) -> Any {
        guard let tree = tree as? Tree else {
            print("Error: Expected tree to be of type Tree, but it's not.")
            return 0
        }
        
        let startToken = tree.children[0] as! Token
        let endToken = tree.children[1] as! Token
        
        if startToken.label == "walkInteger" {
            return FiniteStateMachine.forIntegers(startToken.symbol, endToken.symbol)
        } else {
            return FiniteStateMachine.forCharacters(startToken.symbol, endToken.symbol)
        }
    }
    
    func walkOr (_ tree : VirtualTree) -> Any {
        // loop over children, which could be a list of trees or tokens
        var fsmsToOr: [FiniteStateMachine] = []
        guard let tree = tree as? Tree else {
            print("Error: Expected tree to be of type Tree, but it's not.")
            return 0
        }
        
        for child in tree.children {
            guard let fsm = walkTree(child) as? FiniteStateMachine else {
                print("ERROR: did not get an FSM back from walkTree")
                return 0
            }
            fsmsToOr.append(fsm)
        }
        
        return FiniteStateMachine.orAll(FSMCollection: fsmsToOr)
    }
    
    func walkAnd (_ tree : VirtualTree) -> Any {
        guard let tree = tree as? Tree else {
            print("Error: Expected tree to be of type Tree, but it's not.")
            return 0
        }
        
        guard let fsm1 = walkTree(tree.children[0]) as? FiniteStateMachine else {
            print("Error: fsm1 in walkAnd is not an FSM")
            return 0
        }
        guard let fsm2 = walkTree(tree.children[1]) as? FiniteStateMachine else {
            print("Error: fsm2 in walkAnd is not an FSM")
            return 0
        }
        
        return fsm1.andAnFSM(otherFSM: fsm2)
    }
    
    func walkMinus (_ tree : VirtualTree) -> Any {
        guard let tree = tree as? Tree else {
            print("Error: Expected tree to be of type Tree, but it's not.")
            return 0
        }
        
        guard let fsm1 = walkTree(tree.children[0]) as? FiniteStateMachine else {
            print("Error: fsm1 in walkMinus is not an FSM")
            return 0
        }
        guard let fsm2 = walkTree(tree.children[1]) as? FiniteStateMachine else {
            print("Error: fsm2 in walkMinus is not an FSM")
            return 0
        }
        
        return fsm1.minusAnFSM(otherFSM: fsm2)
    }
    
    func walkConcatentation (_ tree : VirtualTree) -> Any {
        var fsmsToConcat: [FiniteStateMachine] = []
        guard let tree = tree as? Tree else {
            print("Error: Expected tree to be of type Tree, but it's not.")
            return 0
        }
        
        for child in tree.children {
            guard let fsm = walkTree(child) as? FiniteStateMachine else {
                print("ERROR: did not get an FSM back from walkTree")
                return 0
            }
            fsmsToConcat.append(fsm)
        }
        
        return FiniteStateMachine.concatenateAll(fsms: fsmsToConcat)
    }
    
    func extractFirstChild (_ tree : VirtualTree) -> VirtualTree? {
        guard let tree = tree as? Tree else {
            print("Error: Expected tree to be of type Tree, but it's not.")
            return nil
        }
        return tree.children[0]
    }
    
    func walkString (_ tree : VirtualTree) -> Any {
        let token = tree as! Token
        return FiniteStateMachine.forString(token.symbol)
    }
    
    func walkSymbol (_ tree : VirtualTree) -> Any {
        let token = tree as! Token
        return FiniteStateMachine.forString(token.symbol)
    }
    
    func walkInteger (_ tree : VirtualTree) -> Any {
        let token = tree as! Token
        return FiniteStateMachine.forInteger(token.symbol)
    }
    
    func walkIdentifier (_ tree: VirtualTree) -> Any {
        // Ensure tree is a valid Tree instance
        let token = tree as! Token
        
        if let fsm = Grammar.activeGrammar?.macros[token.symbol] {
            return FiniteStateMachine.forIdentifier(fsm)
        } else {
            // if it's not an fsm, it's a char
            if ((Grammar.activeGrammar?.isParser()) == true) {
                return FiniteStateMachine.forString(token.symbol)
            } else {
                return FiniteStateMachine.forCharacter(token.symbol)
            }
        }
    }
    
    func walkAttributes (_ tree : VirtualTree) -> Any {
        guard let tree = tree as? Tree else {
            print("Error: Expected tree to be of type Tree, but it's not.")
            return 0
        }
        
        // build fsm from first child, other children will be attributes
        let child0 = tree.children[0]
        let fsm = walkTree(child0)
        
        guard let finiteStateMachine = fsm as? FiniteStateMachine else {
            print("Error: The FSM returned by walkTree is not of type FiniteStateMachine")
            return 0
        }
        
        // get attributes
        var attributes: [String] = []
        for index in 1..<tree.children.count {
            if let attributeToken = tree.children[index] as? Token {
                let symbol = attributeToken.symbol
                attributes.append(symbol)
            } else {
                print("ERROR: Expected child to be a token, but it isn't")
            }
        }
        
        // override attributes for FSM
        finiteStateMachine.override(attributes)
        return finiteStateMachine
    }
    
    func walkbuildTreeOrTokenFromName (_ tree : VirtualTree) -> Any {
        guard let tree = tree as? Tree else {
            print("Error: Expected tree to be of type Tree, but it's not.")
            return 0
        }
        
        let child0 = tree.children[0]
        let symbol = (child0 as? Token)!.symbol
        let action = Grammar.activeGrammar?.type == "scanner" ? "#buildToken" : "#buildTree"
        let strippedSymbol = symbol.trimmingCharacters(in: CharacterSet(charactersIn: ":"))
        return FiniteStateMachine.forAction([strippedSymbol], isRootBuilding: true, actionName: action)
    }
    
    func walkBuildTreeFromLeftIndex(_ tree: VirtualTree) -> Any {
        return walkbuildTreeFromIndex(tree, negate: false)
    }
    
    func walkbuildTreeFromRightIndex(_ tree: VirtualTree) -> Any {
        return walkbuildTreeFromIndex(tree, negate: true)
    }
    
    func walkbuildTreeFromIndex(_ tree: VirtualTree, negate: Bool) -> Any {
        guard let tree = tree as? Tree else {
            print("Error: Expected tree to be of type Tree, but it's not.")
            return 0
        }
        let child0 = tree.children[0]
        let symbol = (child0 as? Token)!.symbol
        
        // Convert symbol to an integer
        if let integerValue = Int(symbol) {
            let value = negate ? -integerValue : integerValue
            return FiniteStateMachine.forAction([value], isRootBuilding: true, actionName: "#buildTreeFromIndex")
        } else {
            print("Error: Unable to convert symbol \(symbol) to an integer.")
            return 0
        }
    }
    
    func walkTreeBuildingSemanticAction (_ tree : VirtualTree) -> Any {
        guard let tree = tree as? Tree else {
            print("Error: Expected tree to be of type Tree.")
            return 0
        }
        let child0 = tree.children[0]
        return walkSemanticAction(child0, isRootBuilding: true)
    }
    
    func walkNonTreeBuildingSemanticAction (_ tree : VirtualTree) -> Any {
        guard let tree = tree as? Tree else {
            print("Error: Expected tree to be of type Tree.")
            return 0
        }
        let child0 = tree.children[0]
        return walkSemanticAction(child0, isRootBuilding: false)
    }
    
    func walkSemanticAction (_ tree: VirtualTree, isRootBuilding: Bool) -> Any {
        guard let tree = tree as? Tree else {
            print("Error: Expected tree to be of type Tree.")
            return 0
        }

        // Extract the action from the first child (assuming it's a token)
        let actionToken = tree.children[0] as! Token
        let actionSymbol = "#" + actionToken.symbol

        // Extract parameters from the remaining children
        var parameters: [Any] = []
        for i in 1..<tree.children.count {
            if let token = tree.children[i] as? Token {
                let param = token.asConstant()
                parameters.append(param)
            }
        }
        print("PARAMETERS DEBUG: \(parameters)")
        return FiniteStateMachine.forAction(parameters, isRootBuilding: isRootBuilding, actionName: actionSymbol)
    }
    
    func walkLook (_ tree : VirtualTree) -> Any {
        guard let tree = tree as? Tree else {
            print("Error: Expected tree to be of type Tree, but it's not.")
            return 0
        }
        
        // build fsm from first child, other children will be attributes
        let child0 = tree.children[0]
        let fsm = walkTree(child0)
        
        guard let fsmCopy = fsm as? FiniteStateMachine else {
            print("Error: The FSM returned by walkTree is not of type FiniteStateMachine")
            return 0
        }
        
        // need to override attributes to "L"
        fsmCopy.override(["look"])
        return fsmCopy
    }
    
    func processAndDiscardDefaultsNow() {
        //Pick up the tree just built containing either the attributes, keywords, optimize, and output tree,
        //process it with walkTree, and remove it from the tree stack... by replacing the entry by nil..."
        let tree: Tree = self.parser!.treeStack.last as! Tree
        _ = self.walkTree(tree)
        self.parser!.treeStack.removeLast()
        self.parser!.treeStack.append(nil)
    }
    
    func walkAttributeDefaults (_ tree: VirtualTree) {
        //Note: This walk routine is initiated by #processAndDiscardDefaultsNow which subsequently
        //eliminates the tree to prevent generic tree walking later...
     }
    
    func walkOutput (_ tree: VirtualTree) {
        //Note: This walk routine is initiated by #processAndDiscardDefaultsNow which subsequently
        //eliminates the tree to prevent generic tree walking later...
        
//        "All it does is print the output language. We commented out code that records the
//        output language in the grammar since the student version will currently output
//        in the format their tool is written in; i.e., Smalltalk for Smalltalk users versus
//        Swift for Swift users."
        print("Output Language: Swift")
     }
    
    func walkAttributeTerminalDefaults (_ tree: VirtualTree) {
         //Note: This walk routine is initiated by #processAndDiscardDefaultsNow which subsequently
         //eliminates the tree to prevent generic tree walking later...
    }

    func walkAttributeNonterminalDefaults (_ tree: VirtualTree) {
        //Note: This walk routine is initiated by #processAndDiscardDefaultsNow which subsequently
        //eliminates the tree to prevent generic tree walking later...
     }
    
    func walkOptimize (_ tree: VirtualTree) {
        //Note: This walk routine is initiated by #processAndDiscardDefaultsNow which subsequently
        //eliminates the tree to prevent generic tree walking later...
        
        //All it does is allow 'chain reductions' and 'keep nonterminal transitions' to be used
        //by Wilf's parser constructor. It does so by telling the grammar what the optimization is
        //and the more advanced constructor he has to perform the optimizations. They are
        //of no concern to the student constructor... so that code is commented out..."
     }
    
    
        
var scannerTables: Array<Any> = [
    ["ScannerReadaheadTable", 1, ("]", "RK", 35), ("/", "R", 10), ("{", "RK", 36), ("}", "RK", 37), ("\"", "R", 11), ("$", "R", 12), ([256], "L", 21), ("ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz", "RK", 6), ("[", "RK", 33), ("(", "RK", 23), (")", "RK", 24), ("*", "RK", 25), ("+", "RK", 26), ("-", "RK", 2), ("&", "RK", 22), (".", "RK", 3), ([9,10,12,13,32], "R", 7), ("0123456789", "RK", 4), ("=", "RK", 5), ("?", "RK", 31), ("#", "R", 8), ("|", "RK", 34), ("'", "R", 9)],
    ["ScannerReadaheadTable", 2, ([9,10,12,13,32,96,147,148,256], "L", 27), ("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz_0123456789!,+-/\\*~=@%&?|<[]{}()^;#:.$'\"", "L", 27), (">", "RK", 38)],
    ["ScannerReadaheadTable", 3, ([9,10,12,13,32,96,147,148,256], "L", 28), ("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz_0123456789!,+-/\\*~=@%&?|<>[]{}()^;#:$'\"", "L", 28), (".", "RK", 39)],
    ["ScannerReadaheadTable", 4, ([9,10,12,13,32,96,147,148,256], "L", 29), ("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz_!,+-/\\*~=@%&?|<>[]{}()^;#:.$'\"", "L", 29), ("0123456789", "RK", 4)],
    ["ScannerReadaheadTable", 5, ([9,10,12,13,32,96,147,148,256], "L", 30), ("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz_0123456789!,+-/\\*~=@%&?|<[]{}()^;#:.$'\"", "L", 30), (">", "RK", 40)],
    ["ScannerReadaheadTable", 6, ([9,10,12,13,32,96,147,148,256], "L", 32), ("!,+-/\\*~=@%&?|<>[]{}()^;#.$'\"", "L", 32), ("0123456789:ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz", "RK", 6)],
    ["ScannerReadaheadTable", 7, ([96,147,148,256], "L", 1), ("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz_0123456789!,+-/\\*~=@%&?|<>[]{}()^;#:.$'\"", "L", 1), ([9,10,12,13,32], "R", 7)],
    ["ScannerReadaheadTable", 8, ("\"", "R", 14), ("'", "R", 15), ("ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz", "RK", 13)],
    ["ScannerReadaheadTable", 9, ([256], "LK", 42), ("'", "R", 16), ([9,10,12,13,32,96,147,148], "RK", 9), ("!\"#$%&()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_abcdefghijklmnopqrstuvwxyz{|}~", "RK", 9)],
    ["ScannerReadaheadTable", 10, ([9,10,12,13,32], "L", 44), ([96,147,148,256], "LK", 44), ("=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[]^_\\abcdefghijklmnopqrstuvwxyz{|}~!\"#$%&'()*+,-.0123456789:;<", "LK", 44), ("/", "R", 17)],
    ["ScannerReadaheadTable", 11, ([256], "LK", 45), ("\"", "R", 18), ([9,10,12,13,32,96,147,148], "RK", 11), ("!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_abcdefghijklmnopqrstuvwxyz{|}~", "RK", 11)],
    ["ScannerReadaheadTable", 12, ([9,10,12,13,32,96,147,148], "RK", 46), ("!\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_abcdefghijklmnopqrstuvwxyz{|}~", "RK", 46)],
    ["ScannerReadaheadTable", 13, ([9,10,12,13,32,96,147,148,256], "L", 41), ("!,+-/\\*~=@%&?|<>[]{}()^;#.$'\"", "L", 41), ("0123456789:ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz", "RK", 13)],
    ["ScannerReadaheadTable", 14, ([256], "LK", 47), ("\"", "R", 19), ([9,10,12,13,32,96,147,148], "RK", 14), ("!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_abcdefghijklmnopqrstuvwxyz{|}~", "RK", 14)],
    ["ScannerReadaheadTable", 15, ([256], "LK", 48), ("'", "R", 20), ([9,10,12,13,32,96,147,148], "RK", 15), ("!\"#$%&()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_abcdefghijklmnopqrstuvwxyz{|}~", "RK", 15)],
    ["ScannerReadaheadTable", 16, ([9,10,12,13,32,96,147,148,256], "L", 43), ("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz_0123456789!,+-/\\*~=@%&?|<>[]{}()^;#:.$\"", "L", 43), ("'", "RK", 9)],
    ["ScannerReadaheadTable", 17, ([9,32,96,147,148], "R", 17), ("=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_abcdefghijklmnopqrstuvwxyz{|}~!\"#$%&'()*+,-./0123456789:;<", "R", 17), ([256], "LK", 1), ([10,12,13], "R", 1)],
    ["ScannerReadaheadTable", 18, ([9,10,12,13,32,96,147,148,256], "L", 43), ("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz_0123456789!,+-/\\*~=@%&?|<>[]{}()^;#:.$'", "L", 43), ("\"", "RK", 11)],
    ["ScannerReadaheadTable", 19, ([9,10,12,13,32,96,147,148,256], "L", 41), ("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz_0123456789!,+-/\\*~=@%&?|<>[]{}()^;#:.$'", "L", 41), ("\"", "RK", 14)],
    ["ScannerReadaheadTable", 20, ([9,10,12,13,32,96,147,148,256], "L", 41), ("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz_0123456789!,+-/\\*~=@%&?|<>[]{}()^;#:.$\"", "L", 41), ("'", "RK", 15)],
    ["SemanticTable", 21, "buildToken", ["-|"], 1],
    ["SemanticTable", 22, "buildToken", ["And"], 1],
    ["SemanticTable", 23, "buildToken", ["OpenRound"], 1],
    ["SemanticTable", 24, "buildToken", ["CloseRound"], 1],
    ["SemanticTable", 25, "buildToken", ["Star"], 1],
    ["SemanticTable", 26, "buildToken", ["Plus"], 1],
    ["SemanticTable", 27, "buildToken", ["Minus"], 1],
    ["SemanticTable", 28, "buildToken", ["Dot"], 1],
    ["SemanticTable", 29, "buildToken", ["walkInteger"], 1],
    ["SemanticTable", 30, "buildToken", ["Equals"], 1],
    ["SemanticTable", 31, "buildToken", ["QuestionMark"], 1],
    ["SemanticTable", 32, "buildToken", ["walkIdentifier"], 1],
    ["SemanticTable", 33, "buildToken", ["OpenSquare"], 1],
    ["SemanticTable", 34, "buildToken", ["Or"], 1],
    ["SemanticTable", 35, "buildToken", ["CloseSquare"], 1],
    ["SemanticTable", 36, "buildToken", ["OpenCurly"], 1],
    ["SemanticTable", 37, "buildToken", ["CloseCurly"], 1],
    ["SemanticTable", 38, "buildToken", ["RightArrow"], 1],
    ["SemanticTable", 39, "buildToken", ["DotDot"], 1],
    ["SemanticTable", 40, "buildToken", ["FatRightArrow"], 1],
    ["SemanticTable", 41, "buildToken", ["walkSymbol"], 1],
    ["SemanticTable", 42, "syntaxError", ["missing end quote for single quoted string"], 43],
    ["SemanticTable", 43, "buildToken", ["walkString"], 1],
    ["SemanticTable", 44, "syntaxError", ["// is a comment, / alone is not valid"], 1],
    ["SemanticTable", 45, "syntaxError", ["missing end quote for double quoted string"], 43],
    ["SemanticTable", 46, "buildToken", ["walkCharacter"], 1],
    ["SemanticTable", 47, "syntaxError", ["missing end quote for double quoted string"], 41],
    ["SemanticTable", 48, "syntaxError", ["missing end quote for single quoted string"], 41]]

var parserTables: Array<Any> =
    [
//        ["keywords", "stack", "noStack", "read", "look", "node", "noNode", "keep", "noKeep", "parser", "scanner", "super", "superScanner", "attribute", "defaults", "keywords", "output", "optimize", "terminal", "nonterminal"],
//        ["ReadaheadTable", 1, ("GrammarType", "RSN", 2), ("scanner", "RS", 172), ("superScanner", "RS", 173), ("super", "RS", 3), ("parser", "RS", 174), ("Grammar", "RSN", 177)],
//        ["ReadaheadTable", 2, ("walkString", "RSN", 69), ("Macro", "RSN", 4), ("keywords", "RS", 5), ("attribute", "RS", 6), ("optimize", "RS", 7), ("Name", "RSN", 8), ("output", "RS", 9), ("Rules", "RSN", 70), ("walkIdentifier", "RSN", 69), ("LeftPart", "RSN", 10), ("Defaults", "RSN", 175), ("Production", "RSN", 11)],
//        ["ReadaheadTable", 3, ("scanner", "RS", 176)],
//        ["ReadaheadTable", 4, ("walkString", "RSN", 69), ("Macro", "RSN", 4), ("Name", "RSN", 8), ("walkIdentifier", "RSN", 69), ("LeftPart", "RSN", 10), ("Production", "RSN", 11), ("-|", "L", 72)],
//        ["ReadaheadTable", 5, ("walkString", "RSN", 69), ("Name", "RSN", 12), ("walkIdentifier", "RSN", 69)],
//        ["ReadaheadTable", 6, ("defaults", "RS", 13), ("terminal", "RS", 14), ("nonterminal", "RS", 15)],
//        ["ReadaheadTable", 7, ("walkString", "RSN", 69), ("Name", "RSN", 16), ("walkIdentifier", "RSN", 69)],
//        ["ReadaheadTable", 8, ("OpenCurly", "RS", 17), ("Equals", "RS", 18), ("RightArrow", "L", 73)],
//        ["ReadaheadTable", 9, ("walkString", "RSN", 69), ("Name", "RSN", 19), ("walkIdentifier", "RSN", 69)],
//        ["ReadaheadTable", 10, ("RightArrow", "RS", 20), ("RightParts", "RSN", 21), ("RightPart", "RSN", 22)],
//        ["ReadaheadTable", 11, ("walkString", "RSN", 69), ("Macro", "RSN", 4), ("Name", "RSN", 8), ("walkIdentifier", "RSN", 69), ("LeftPart", "RSN", 10), ("Production", "RSN", 11), ("-|", "L", 72)],
//        ["ReadaheadTable", 12, ("walkString", "RSN", 69), ("Name", "RSN", 12), ("Dot", "RS", 85), ("walkIdentifier", "RSN", 69)],
//        ["ReadaheadTable", 13, ("walkString", "RSN", 69), ("Name", "RSN", 24), ("walkIdentifier", "RSN", 69)],
//        ["ReadaheadTable", 14, ("defaults", "RS", 25)],
//        ["ReadaheadTable", 15, ("defaults", "RS", 26)],
//        ["ReadaheadTable", 16, ("Dot", "RS", 86)],
//        ["ReadaheadTable", 17, ("AndExpression", "RSN", 27), ("Primary", "RSN", 28), ("Alternation", "RSN", 29), ("Secondary", "RSN", 30), ("Byte", "RSN", 31), ("OpenCurly", "RS", 32), ("walkString", "RSN", 69), ("walkSymbol", "RSN", 33), ("walkInteger", "RSN", 80), ("SemanticAction", "RSN", 88), ("walkCharacter", "RSN", 80), ("walkIdentifier", "RSN", 69), ("Expression", "RSN", 34), ("Concatenation", "RSN", 35), ("RepetitionOption", "RSN", 36), ("Name", "RSN", 79), ("OpenRound", "RS", 37), ("And", "L", 144), ("Minus", "L", 144), ("CloseCurly", "L", 144), ("Dot", "L", 144), ("CloseRound", "L", 144), ("FatRightArrow", "L", 144), ("RightArrow", "L", 144)],
//        ["ReadaheadTable", 18, ("AndExpression", "RSN", 27), ("Primary", "RSN", 28), ("Alternation", "RSN", 29), ("Secondary", "RSN", 30), ("Byte", "RSN", 31), ("OpenCurly", "RS", 32), ("walkString", "RSN", 69), ("walkSymbol", "RSN", 33), ("walkInteger", "RSN", 80), ("SemanticAction", "RSN", 88), ("walkCharacter", "RSN", 80), ("walkIdentifier", "RSN", 69), ("Expression", "RSN", 38), ("Concatenation", "RSN", 35), ("RepetitionOption", "RSN", 36), ("Name", "RSN", 79), ("OpenRound", "RS", 37), ("And", "L", 144), ("Minus", "L", 144), ("CloseCurly", "L", 144), ("Dot", "L", 144), ("CloseRound", "L", 144), ("FatRightArrow", "L", 144), ("RightArrow", "L", 144)],
//        ["ReadaheadTable", 19, ("Dot", "RS", 89)],
//        ["ReadaheadTable", 20, ("AndExpression", "RSN", 27), ("Primary", "RSN", 28), ("walkString", "RSN", 69), ("Alternation", "RSN", 29), ("Secondary", "RSN", 30), ("Byte", "RSN", 31), ("OpenCurly", "RS", 32), ("walkSymbol", "RSN", 33), ("walkInteger", "RSN", 80), ("SemanticAction", "RSN", 88), ("walkCharacter", "RSN", 80), ("walkIdentifier", "RSN", 69), ("Expression", "RSN", 39), ("Concatenation", "RSN", 35), ("RepetitionOption", "RSN", 36), ("OpenRound", "RS", 37), ("Name", "RSN", 79), ("And", "L", 144), ("Minus", "L", 144), ("CloseCurly", "L", 144), ("Dot", "L", 144), ("CloseRound", "L", 144), ("FatRightArrow", "L", 144), ("RightArrow", "L", 144)],
//        ["ReadaheadTable", 21, ("Dot", "RS", 90)],
//        ["ReadaheadTable", 22, ("RightArrow", "RS", 20), ("RightPart", "RSN", 22), ("Dot", "L", 84)],
//        ["ReadaheadTable", 23, ("walkString", "RSN", 69), ("Macro", "RSN", 4), ("keywords", "RS", 5), ("attribute", "RS", 6), ("Name", "RSN", 8), ("walkIdentifier", "RSN", 69), ("Rules", "RSN", 70), ("optimize", "RS", 7), ("output", "RS", 9), ("LeftPart", "RSN", 10), ("Defaults", "RSN", 175), ("Production", "RSN", 11)],
//        ["ReadaheadTable", 24, ("walkString", "RSN", 69), ("Name", "RSN", 24), ("Dot", "RS", 91), ("walkIdentifier", "RSN", 69)],
//        ["ReadaheadTable", 25, ("walkString", "RSN", 69), ("Name", "RSN", 40), ("walkIdentifier", "RSN", 69)],
//        ["ReadaheadTable", 26, ("walkString", "RSN", 69), ("Name", "RSN", 41), ("walkIdentifier", "RSN", 69)],
//        ["ReadaheadTable", 27, ("Minus", "RS", 42), ("CloseCurly", "L", 75), ("Dot", "L", 75), ("CloseRound", "L", 75), ("FatRightArrow", "L", 75), ("RightArrow", "L", 75)],
//        ["ReadaheadTable", 28, ("QuestionMark", "RS", 92), ("Star", "RS", 93), ("Plus", "RS", 94), ("walkSymbol", "L", 76), ("OpenRound", "L", 76), ("OpenCurly", "L", 76), ("walkIdentifier", "L", 76), ("walkString", "L", 76), ("walkCharacter", "L", 76), ("walkInteger", "L", 76), ("Or", "L", 76), ("And", "L", 76), ("Minus", "L", 76), ("CloseCurly", "L", 76), ("Dot", "L", 76), ("CloseRound", "L", 76), ("FatRightArrow", "L", 76), ("RightArrow", "L", 76)],
//        ["ReadaheadTable", 29, ("And", "RS", 43), ("Minus", "L", 77), ("CloseCurly", "L", 77), ("Dot", "L", 77), ("CloseRound", "L", 77), ("FatRightArrow", "L", 77), ("RightArrow", "L", 77)],
//        ["ReadaheadTable", 30, ("OpenSquare", "RS", 44), ("Star", "L", 78), ("QuestionMark", "L", 78), ("Plus", "L", 78), ("walkSymbol", "L", 78), ("OpenRound", "L", 78), ("OpenCurly", "L", 78), ("walkIdentifier", "L", 78), ("walkString", "L", 78), ("walkCharacter", "L", 78), ("walkInteger", "L", 78), ("Or", "L", 78), ("And", "L", 78), ("Minus", "L", 78), ("CloseCurly", "L", 78), ("Dot", "L", 78), ("CloseRound", "L", 78), ("FatRightArrow", "L", 78), ("RightArrow", "L", 78)],
//        ["ReadaheadTable", 31, ("DotDot", "RS", 45), ("OpenSquare", "L", 79), ("Star", "L", 79), ("QuestionMark", "L", 79), ("Plus", "L", 79), ("walkSymbol", "L", 79), ("OpenRound", "L", 79), ("OpenCurly", "L", 79), ("walkIdentifier", "L", 79), ("walkString", "L", 79), ("walkCharacter", "L", 79), ("walkInteger", "L", 79), ("Or", "L", 79), ("And", "L", 79), ("Minus", "L", 79), ("CloseCurly", "L", 79), ("Dot", "L", 79), ("CloseRound", "L", 79), ("FatRightArrow", "L", 79), ("RightArrow", "L", 79)],
//        ["ReadaheadTable", 32, ("AndExpression", "RSN", 27), ("Primary", "RSN", 28), ("Alternation", "RSN", 29), ("Secondary", "RSN", 30), ("Byte", "RSN", 31), ("OpenCurly", "RS", 32), ("walkString", "RSN", 69), ("walkSymbol", "RSN", 33), ("walkInteger", "RSN", 80), ("SemanticAction", "RSN", 88), ("walkCharacter", "RSN", 80), ("walkIdentifier", "RSN", 69), ("Expression", "RSN", 46), ("Concatenation", "RSN", 35), ("RepetitionOption", "RSN", 36), ("Name", "RSN", 79), ("OpenRound", "RS", 37), ("And", "L", 144), ("Minus", "L", 144), ("CloseCurly", "L", 144), ("Dot", "L", 144), ("CloseRound", "L", 144), ("FatRightArrow", "L", 144), ("RightArrow", "L", 144)],
//        ["ReadaheadTable", 33, ("OpenSquare", "RS", 47), ("Star", "L", 87), ("QuestionMark", "L", 87), ("Plus", "L", 87), ("walkSymbol", "L", 87), ("OpenRound", "L", 87), ("OpenCurly", "L", 87), ("walkIdentifier", "L", 87), ("walkString", "L", 87), ("walkCharacter", "L", 87), ("walkInteger", "L", 87), ("Or", "L", 87), ("And", "L", 87), ("Minus", "L", 87), ("RightArrow", "L", 87), ("Dot", "L", 87), ("CloseCurly", "L", 87), ("CloseRound", "L", 87), ("FatRightArrow", "L", 87)],
//        ["ReadaheadTable", 34, ("CloseCurly", "RS", 97)],
//        ["ReadaheadTable", 35, ("Or", "RS", 48), ("And", "L", 81), ("Minus", "L", 81), ("CloseCurly", "L", 81), ("Dot", "L", 81), ("CloseRound", "L", 81), ("FatRightArrow", "L", 81), ("RightArrow", "L", 81)],
//        ["ReadaheadTable", 36, ("Primary", "RSN", 28), ("walkString", "RSN", 69), ("Secondary", "RSN", 30), ("Byte", "RSN", 31), ("OpenCurly", "RS", 32), ("walkSymbol", "RSN", 33), ("walkInteger", "RSN", 80), ("SemanticAction", "RSN", 88), ("walkCharacter", "RSN", 80), ("walkIdentifier", "RSN", 69), ("RepetitionOption", "RSN", 49), ("Name", "RSN", 79), ("OpenRound", "RS", 37), ("Or", "L", 82), ("And", "L", 82), ("Minus", "L", 82), ("CloseCurly", "L", 82), ("Dot", "L", 82), ("CloseRound", "L", 82), ("FatRightArrow", "L", 82), ("RightArrow", "L", 82)],
//        ["ReadaheadTable", 37, ("AndExpression", "RSN", 27), ("Primary", "RSN", 28), ("walkString", "RSN", 69), ("Secondary", "RSN", 30), ("Byte", "RSN", 31), ("OpenCurly", "RS", 32), ("Alternation", "RSN", 29), ("walkSymbol", "RSN", 33), ("walkInteger", "RSN", 80), ("SemanticAction", "RSN", 88), ("walkCharacter", "RSN", 80), ("walkIdentifier", "RSN", 69), ("Expression", "RSN", 50), ("Concatenation", "RSN", 35), ("OpenRound", "RS", 37), ("Name", "RSN", 79), ("RepetitionOption", "RSN", 36), ("And", "L", 144), ("Minus", "L", 144), ("CloseCurly", "L", 144), ("Dot", "L", 144), ("CloseRound", "L", 144), ("FatRightArrow", "L", 144), ("RightArrow", "L", 144)],
//        ["ReadaheadTable", 38, ("Dot", "RS", 100)],
//        ["ReadaheadTable", 39, ("FatRightArrow", "RS", 51), ("RightArrow", "L", 83), ("Dot", "L", 83)],
//        ["ReadaheadTable", 40, ("walkString", "RSN", 69), ("Name", "RSN", 40), ("Dot", "RS", 101), ("walkIdentifier", "RSN", 69)],
//        ["ReadaheadTable", 41, ("walkString", "RSN", 69), ("Name", "RSN", 41), ("Dot", "RS", 102), ("walkIdentifier", "RSN", 69)],
//        ["ReadaheadTable", 42, ("AndExpression", "RSN", 103), ("Primary", "RSN", 28), ("walkString", "RSN", 69), ("Alternation", "RSN", 29), ("Byte", "RSN", 31), ("OpenCurly", "RS", 32), ("Secondary", "RSN", 30), ("walkSymbol", "RSN", 33), ("walkInteger", "RSN", 80), ("SemanticAction", "RSN", 88), ("walkCharacter", "RSN", 80), ("walkIdentifier", "RSN", 69), ("Concatenation", "RSN", 35), ("OpenRound", "RS", 37), ("Name", "RSN", 79), ("RepetitionOption", "RSN", 36), ("And", "L", 144), ("Minus", "L", 144), ("CloseCurly", "L", 144), ("Dot", "L", 144), ("CloseRound", "L", 144), ("FatRightArrow", "L", 144), ("RightArrow", "L", 144)],
//        ["ReadaheadTable", 43, ("Primary", "RSN", 28), ("Alternation", "RSN", 104), ("walkString", "RSN", 69), ("Byte", "RSN", 31), ("OpenCurly", "RS", 32), ("Secondary", "RSN", 30), ("walkSymbol", "RSN", 33), ("walkInteger", "RSN", 80), ("SemanticAction", "RSN", 88), ("walkCharacter", "RSN", 80), ("walkIdentifier", "RSN", 69), ("Concatenation", "RSN", 35), ("RepetitionOption", "RSN", 36), ("Name", "RSN", 79), ("OpenRound", "RS", 37), ("And", "L", 144), ("Minus", "L", 144), ("CloseCurly", "L", 144), ("Dot", "L", 144), ("CloseRound", "L", 144), ("FatRightArrow", "L", 144), ("RightArrow", "L", 144)],
//        ["ReadaheadTable", 44, ("Attribute", "RSN", 52), ("keep", "RSN", 95), ("noNode", "RSN", 95), ("noStack", "RSN", 95), ("CloseSquare", "RS", 105), ("read", "RSN", 95), ("look", "RSN", 95), ("stack", "RSN", 95), ("node", "RSN", 95), ("noKeep", "RSN", 95)],
//        ["ReadaheadTable", 45, ("Byte", "RSN", 106), ("walkInteger", "RSN", 80), ("walkCharacter", "RSN", 80)],
//        ["ReadaheadTable", 46, ("CloseCurly", "RS", 107)],
//        ["ReadaheadTable", 47, ("walkString", "RSN", 69), ("walkSymbol", "RSN", 96), ("SemanticActionParameter", "RSN", 53), ("walkCharacter", "RSN", 80), ("walkIdentifier", "RSN", 69), ("CloseSquare", "RS", 108), ("Byte", "RSN", 96), ("Name", "RSN", 96), ("walkInteger", "RSN", 80)],
//        ["ReadaheadTable", 48, ("Primary", "RSN", 28), ("walkString", "RSN", 69), ("Secondary", "RSN", 30), ("Byte", "RSN", 31), ("OpenCurly", "RS", 32), ("walkSymbol", "RSN", 33), ("walkInteger", "RSN", 80), ("SemanticAction", "RSN", 88), ("walkCharacter", "RSN", 80), ("walkIdentifier", "RSN", 69), ("Concatenation", "RSN", 54), ("RepetitionOption", "RSN", 36), ("Name", "RSN", 79), ("OpenRound", "RS", 37)],
//        ["ReadaheadTable", 49, ("Primary", "RSN", 28), ("walkString", "RSN", 69), ("Secondary", "RSN", 30), ("Byte", "RSN", 31), ("OpenCurly", "RS", 32), ("walkSymbol", "RSN", 33), ("walkInteger", "RSN", 80), ("SemanticAction", "RSN", 88), ("walkCharacter", "RSN", 80), ("walkIdentifier", "RSN", 69), ("RepetitionOption", "RSN", 49), ("Name", "RSN", 79), ("OpenRound", "RS", 37), ("Or", "L", 98), ("And", "L", 98), ("Minus", "L", 98), ("CloseCurly", "L", 98), ("Dot", "L", 98), ("CloseRound", "L", 98), ("FatRightArrow", "L", 98), ("RightArrow", "L", 98)],
//        ["ReadaheadTable", 50, ("CloseRound", "RS", 99)],
//        ["ReadaheadTable", 51, ("Minus", "RS", 55), ("walkSymbol", "RSN", 33), ("walkString", "RSN", 69), ("Name", "RSN", 110), ("walkIdentifier", "RSN", 69), ("Plus", "RS", 56), ("TreeBuildingOptions", "RSN", 111), ("SemanticAction", "RSN", 112), ("walkInteger", "RSN", 113)],
//        ["ReadaheadTable", 52, ("Attribute", "RSN", 52), ("keep", "RSN", 95), ("noNode", "RSN", 95), ("noStack", "RSN", 95), ("CloseSquare", "RS", 105), ("read", "RSN", 95), ("look", "RSN", 95), ("stack", "RSN", 95), ("node", "RSN", 95), ("noKeep", "RSN", 95)],
//        ["ReadaheadTable", 53, ("walkString", "RSN", 69), ("walkSymbol", "RSN", 96), ("Name", "RSN", 96), ("walkIdentifier", "RSN", 69), ("Byte", "RSN", 96), ("walkCharacter", "RSN", 80), ("CloseSquare", "RS", 108), ("SemanticActionParameter", "RSN", 53), ("walkInteger", "RSN", 80)],
//        ["ReadaheadTable", 54, ("Or", "RS", 48), ("And", "L", 109), ("Minus", "L", 109), ("CloseCurly", "L", 109), ("Dot", "L", 109), ("CloseRound", "L", 109), ("FatRightArrow", "L", 109), ("RightArrow", "L", 109)],
//        ["ReadaheadTable", 55, ("walkInteger", "RSN", 114)],
//        ["ReadaheadTable", 56, ("walkInteger", "RSN", 113)],
//        ["ReadbackTable", 57, (("GrammarType", 2), "RSN", 129), (("Defaults", 175), "RSN", 57)],
//        ["ReadbackTable", 58, (("Macro", 4), "RSN", 58), (("Production", 11), "RSN", 58), (("GrammarType", 2), "L", 142), (("Defaults", 175), "L", 142)],
//        ["ReadbackTable", 59, (("RightPart", 22), "RSN", 59), (("LeftPart", 10), "L", 145)],
//        ["ReadbackTable", 60, (("RepetitionOption", 49), "RSN", 60), (("RepetitionOption", 36), "RSN", 157)],
//        ["ReadbackTable", 61, (("Attribute", 52), "RSN", 61), (("OpenSquare", 44), "RS", 116)],
//        ["ReadbackTable", 62, (("SemanticActionParameter", 53), "RSN", 62), (("OpenSquare", 47), "RS", 87)],
//        ["ReadbackTable", 63, (("Plus", 56), "RS", 170), (("FatRightArrow", 51), "L", 170)],
//        ["ReadbackTable", 64, (("keywords", 5), "RS", 146), (("Name", 12), "RSN", 64)],
//        ["ReadbackTable", 65, (("defaults", 13), "RS", 117), (("Name", 24), "RSN", 65)],
//        ["ReadbackTable", 66, (("defaults", 25), "RS", 118), (("Name", 40), "RSN", 66)],
//        ["ReadbackTable", 67, (("defaults", 26), "RS", 119), (("Name", 41), "RSN", 67)],
//        ["ReadbackTable", 68, (("Concatenation", 54), "RSN", 115), (("Concatenation", 35), "RSN", 166)],
//        ["ShiftbackTable", 69, 1, 126],
//        ["ShiftbackTable", 70, 1, 57],
//        ["ShiftbackTable", 71, 1, 133],
//        ["ShiftbackTable", 72, 1, 58],
//        ["ShiftbackTable", 73, 1, 143],
//        ["ShiftbackTable", 74, 2, 133],
//        ["ShiftbackTable", 75, 1, 121],
//        ["ShiftbackTable", 76, 1, 125],
//        ["ShiftbackTable", 77, 1, 131],
//        ["ShiftbackTable", 78, 1, 135],
//        ["ShiftbackTable", 79, 1, 138],
//        ["ShiftbackTable", 80, 1, 139],
//        ["ShiftbackTable", 81, 1, 137],
//        ["ShiftbackTable", 82, 1, 122],
//        ["ShiftbackTable", 83, 2, 140],
//        ["ShiftbackTable", 84, 1, 59],
//        ["ShiftbackTable", 85, 2, 64],
//        ["ShiftbackTable", 86, 3, 147],
//        ["ShiftbackTable", 87, 1, 148],
//        ["ShiftbackTable", 88, 1, 149],
//        ["ShiftbackTable", 89, 3, 150],
//        ["ShiftbackTable", 90, 3, 151],
//        ["ShiftbackTable", 91, 2, 65],
//        ["ShiftbackTable", 92, 2, 153],
//        ["ShiftbackTable", 93, 2, 154],
//        ["ShiftbackTable", 94, 2, 155],
//        ["ShiftbackTable", 95, 1, 136],
//        ["ShiftbackTable", 96, 1, 128],
//        ["ShiftbackTable", 97, 4, 156],
//        ["ShiftbackTable", 98, 1, 60],
//        ["ShiftbackTable", 99, 3, 138],
//        ["ShiftbackTable", 100, 4, 158],
//        ["ShiftbackTable", 101, 2, 66],
//        ["ShiftbackTable", 102, 2, 67],
//        ["ShiftbackTable", 103, 3, 161],
//        ["ShiftbackTable", 104, 3, 162],
//        ["ShiftbackTable", 105, 1, 61],
//        ["ShiftbackTable", 106, 3, 164],
//        ["ShiftbackTable", 107, 3, 165],
//        ["ShiftbackTable", 108, 1, 62],
//        ["ShiftbackTable", 109, 2, 68],
//        ["ShiftbackTable", 110, 1, 167],
//        ["ShiftbackTable", 111, 4, 168],
//        ["ShiftbackTable", 112, 1, 169],
//        ["ShiftbackTable", 113, 1, 63],
//        ["ShiftbackTable", 114, 2, 171],
//        ["ShiftbackTable", 115, 1, 68],
//        ["ShiftbackTable", 116, 1, 163],
//        ["ShiftbackTable", 117, 1, 152],
//        ["ShiftbackTable", 118, 2, 159],
//        ["ShiftbackTable", 119, 2, 160],
//        ["ReduceTable", 120, "SemanticAction", (17, "RSN", 88), (18, "RSN", 88), (20, "RSN", 88), (32, "RSN", 88), (36, "RSN", 88), (37, "RSN", 88), (42, "RSN", 88), (43, "RSN", 88), (48, "RSN", 88), (49, "RSN", 88), (51, "RSN", 112)],
//        ["ReduceTable", 121, "Expression", (17, "RSN", 34), (18, "RSN", 38), (20, "RSN", 39), (32, "RSN", 46), (37, "RSN", 50)],
//        ["ReduceTable", 122, "Concatenation", (17, "RSN", 35), (18, "RSN", 35), (20, "RSN", 35), (32, "RSN", 35), (37, "RSN", 35), (42, "RSN", 35), (43, "RSN", 35), (48, "RSN", 54)],
//        ["ReduceTable", 123, "LeftPart", (2, "RSN", 10), (4, "RSN", 10), (11, "RSN", 10), (175, "RSN", 10)],
//        ["ReduceTable", 124, "Macro", (2, "RSN", 4), (4, "RSN", 4), (11, "RSN", 4), (175, "RSN", 4)],
//        ["ReduceTable", 125, "RepetitionOption", (17, "RSN", 36), (18, "RSN", 36), (20, "RSN", 36), (32, "RSN", 36), (36, "RSN", 49), (37, "RSN", 36), (42, "RSN", 36), (43, "RSN", 36), (48, "RSN", 36), (49, "RSN", 49)],
//        ["ReduceTable", 126, "Name", (2, "RSN", 8), (4, "RSN", 8), (5, "RSN", 12), (7, "RSN", 16), (9, "RSN", 19), (11, "RSN", 8), (12, "RSN", 12), (13, "RSN", 24), (17, "RSN", 79), (18, "RSN", 79), (20, "RSN", 79), (175, "RSN", 8), (24, "RSN", 24), (25, "RSN", 40), (26, "RSN", 41), (32, "RSN", 79), (36, "RSN", 79), (37, "RSN", 79), (40, "RSN", 40), (41, "RSN", 41), (42, "RSN", 79), (43, "RSN", 79), (47, "RSN", 96), (48, "RSN", 79), (49, "RSN", 79), (51, "RSN", 110), (53, "RSN", 96)],
//        ["ReduceTable", 127, "Defaults", (2, "RSN", 175), (175, "RSN", 175)],
//        ["ReduceTable", 128, "SemanticActionParameter", (47, "RSN", 53), (53, "RSN", 53)],
//        ["ReduceTable", 129, "Grammar", (1, "RSN", 177)],
//        ["ReduceTable", 130, "TreeBuildingOptions", (51, "RSN", 111)],
//        ["ReduceTable", 131, "AndExpression", (17, "RSN", 27), (18, "RSN", 27), (20, "RSN", 27), (32, "RSN", 27), (37, "RSN", 27), (42, "RSN", 103)],
//        ["ReduceTable", 132, "Production", (2, "RSN", 11), (4, "RSN", 11), (11, "RSN", 11), (175, "RSN", 11)],
//        ["ReduceTable", 133, "GrammarType", (1, "RSN", 2)],
//        ["ReduceTable", 134, "Rules", (2, "RSN", 70), (175, "RSN", 70)],
//        ["ReduceTable", 135, "Primary", (17, "RSN", 28), (18, "RSN", 28), (20, "RSN", 28), (32, "RSN", 28), (36, "RSN", 28), (37, "RSN", 28), (42, "RSN", 28), (43, "RSN", 28), (48, "RSN", 28), (49, "RSN", 28)],
//        ["ReduceTable", 136, "Attribute", (44, "RSN", 52), (52, "RSN", 52)],
//        ["ReduceTable", 137, "Alternation", (17, "RSN", 29), (18, "RSN", 29), (20, "RSN", 29), (32, "RSN", 29), (37, "RSN", 29), (42, "RSN", 29), (43, "RSN", 104)],
//        ["ReduceTable", 138, "Secondary", (17, "RSN", 30), (18, "RSN", 30), (20, "RSN", 30), (32, "RSN", 30), (36, "RSN", 30), (37, "RSN", 30), (42, "RSN", 30), (43, "RSN", 30), (48, "RSN", 30), (49, "RSN", 30)],
//        ["ReduceTable", 139, "Byte", (17, "RSN", 31), (18, "RSN", 31), (20, "RSN", 31), (32, "RSN", 31), (36, "RSN", 31), (37, "RSN", 31), (42, "RSN", 31), (43, "RSN", 31), (45, "RSN", 106), (47, "RSN", 96), (48, "RSN", 31), (49, "RSN", 31), (53, "RSN", 96)],
//        ["ReduceTable", 140, "RightPart", (10, "RSN", 22), (22, "RSN", 22)],
//        ["ReduceTable", 141, "RightParts", (10, "RSN", 21)],
//        ["SemanticTable", 142, "buildTree", ["walkGrammar"], 134],
//        ["SemanticTable", 143, "buildTree", ["walkLeftPart"], 123],
//        ["SemanticTable", 144, "buildTree", ["walkEpsilon"], 137],
//        ["SemanticTable", 145, "buildTree", ["walkOr"], 141],
//        ["SemanticTable", 146, "buildTree", ["walkKeywords"], 127],
//        ["SemanticTable", 147, "buildTree", ["walkOptimize"], 127],
//        ["SemanticTable", 148, "buildTree", ["walkSemanticAction"], 120],
//        ["SemanticTable", 149, "buildTree", ["walkNonTreeBuildingSemanticAction"], 135],
//        ["SemanticTable", 150, "buildTree", ["walkOutput"], 127],
//        ["SemanticTable", 151, "buildTree", ["walkProduction"], 132],
//        ["SemanticTable", 152, "buildTree", ["walkAttributeDefaults"], 127],
//        ["SemanticTable", 153, "buildTree", ["walkQuestionMark"], 125],
//        ["SemanticTable", 154, "buildTree", ["walkStar"], 125],
//        ["SemanticTable", 155, "buildTree", ["walkPlus"], 125],
//        ["SemanticTable", 156, "buildTree", ["walkLeftPartWithLookahead"], 123],
//        ["SemanticTable", 157, "buildTree", ["walkConcatenation"], 122],
//        ["SemanticTable", 158, "buildTree", ["walkMacro"], 124],
//        ["SemanticTable", 159, "buildTree", ["walkAttributeTerminalDefaults"], 127],
//        ["SemanticTable", 160, "buildTree", ["walkAttributeNonterminalDefaults"], 127],
//        ["SemanticTable", 161, "buildTree", ["walkMinus"], 121],
//        ["SemanticTable", 162, "buildTree", ["walkAnd"], 131],
//        ["SemanticTable", 163, "buildTree", ["walkAttributes"], 135],
//        ["SemanticTable", 164, "buildTree", ["walkDotDot"], 138],
//        ["SemanticTable", 165, "buildTree", ["walkLook"], 138],
//        ["SemanticTable", 166, "buildTree", ["walkOr"], 137],
//        ["SemanticTable", 167, "buildTree", ["walkBuildTreeOrTokenFromName"], 130],
//        ["SemanticTable", 168, "buildTree", ["walkConcatenation"], 140],
//        ["SemanticTable", 169, "buildTree", ["walkTreeBuildingSemanticAction"], 130],
//        ["SemanticTable", 170, "buildTree", ["walkBuildTreeFromLeftIndex"], 130],
//        ["SemanticTable", 171, "buildTree", ["walkBuildTreeFromRightIndex"], 130],
//        ["SemanticTable", 172, "processTypeNow", ["scanner"], 71],
//        ["SemanticTable", 173, "processTypeNow", ["superScanner"], 71],
//        ["SemanticTable", 174, "processTypeNow", ["parser"], 71],
//        ["SemanticTable", 175, "processAndDiscardDefaultsNow", [], 23],
//        ["SemanticTable", 176, "processTypeNow", ["superScanner"], 74],
//        ["AcceptTable", 177]]
        ["keywords", "stack", "noStack", "read", "look", "node", "noNode", "keep", "noKeep", "parser", "scanner", "super", "superScanner", "attribute", "defaults", "keywords", "output", "optimize", "terminal", "nonterminal"],
        ["ReadaheadTable", 1, ("|-", "L", 2)],
        ["ReadaheadTable", 2, ("super", "RS", 3), ("GrammarType", "L", 4), ("scanner", "RS", 5), ("parser", "RS", 6), ("superScanner", "RS", 7)],
        ["ReadaheadTable", 3, ("scanner", "RS", 8)],
        ["ReadaheadTable", 4, ("keywords", "L", 9), ("attribute", "RS", 10), ("output", "L", 11), ("Defaults", "L", 12), ("optimize", "L", 13), ("Production", "L", 14), ("Rules", "RSN", 15), ("Macro", "L", 16)],
        ["ReadaheadTable", 5, ("attribute", "L", -1), ("keywords", "L", -1), ("output", "L", -1), ("optimize", "L", -1), ("walkIdentifier:", "L", -1), ("walkString:", "L", -1)],
        ["ReadaheadTable", 6, ("attribute", "L", -1), ("keywords", "L", -1), ("output", "L", -1), ("optimize", "L", -1), ("walkIdentifier:", "L", -1), ("walkString:", "L", -1)],
        ["ReadaheadTable", 7, ("attribute", "L", -1), ("keywords", "L", -1), ("output", "L", -1), ("optimize", "L", -1), ("walkIdentifier:", "L", -1), ("walkString:", "L", -1)],
        ["ReadaheadTable", 8, ("attribute", "L", -1), ("keywords", "L", -1), ("output", "L", -1), ("optimize", "L", -1), ("walkIdentifier:", "L", -1), ("walkString:", "L", -1)],
        ["ReadaheadTable", 9, ("walkString:", "RSN", 21), ("walkIdentifier:", "RSN", 22), ("Name", "L", 23)],
        ["ReadaheadTable", 10, ("defaults", "L", 24), ("nonterminal", "RS", 25), ("terminal", "RS", 26)],
        ["ReadaheadTable", 11, ("Name", "RSN", 27), ("walkIdentifier:", "RSN", 22), ("walkString:", "RSN", 21)],
        ["ReadaheadTable", 12, ("keywords", "L", -1), ("attribute", "L", -1), ("output", "L", -1), ("optimize", "L", -1), ("walkIdentifier:", "L", -1), ("walkString:", "L", -1)],
        ["ReadaheadTable", 13, ("walkString:", "RSN", 21), ("walkIdentifier:", "RSN", 22), ("Name", "RSN", 29)],
        ["ReadaheadTable", 14, ("LeftPart", "L", 30), ("Name", "RSN", 31), ("Production", "L", 14), ("Macro", "L", 16), ("-|", "L", -1)],
        ["ReadaheadTable", 15, ],
        ["ReadaheadTable", 16, ("LeftPart", "L", 30), ("Name", "RSN", 31), ("Production", "L", 14), ("Macro", "L", 16), ("-|", "L", -1)],
        ["ReadaheadTable", 17, ("attribute", "L", -1), ("keywords", "L", -1), ("output", "L", -1), ("optimize", "L", -1), ("walkIdentifier:", "L", -1), ("walkString:", "L", -1)],
        ["ReadaheadTable", 18, ("attribute", "L", -1), ("keywords", "L", -1), ("output", "L", -1), ("optimize", "L", -1), ("walkIdentifier:", "L", -1), ("walkString:", "L", -1)],
        ["ReadaheadTable", 19, ("attribute", "L", -1), ("keywords", "L", -1), ("output", "L", -1), ("optimize", "L", -1), ("walkIdentifier:", "L", -1), ("walkString:", "L", -1)],
        ["ReadaheadTable", 20, ("attribute", "L", -1), ("keywords", "L", -1), ("output", "L", -1), ("optimize", "L", -1), ("walkIdentifier:", "L", -1), ("walkString:", "L", -1)],
        ["ReadaheadTable", 21, ("walkIdentifier:", "L", -1), ("walkString:", "L", -1), ("Dot", "L", -1), ("Equals", "L", -1), ("RightArrow", "L", -1), ("OpenCurly", "L", -1), ("walkSymbol:", "L", -1), ("walkCharacter:", "L", -1), ("walkInteger:", "L", -1), ("CloseSquare", "L", -1), ("OpenSquare", "L", -1), ("Or", "L", -1), ("OpenRound", "L", -1), ("Star", "L", -1), ("QuestionMark", "L", -1), ("Plus", "L", -1), ("Minus", "L", -1), ("And", "L", -1), ("CloseRound", "L", -1), ("CloseCurly", "L", -1), ("FatRightArrow", "L", -1)],
        ["ReadaheadTable", 22, ("walkIdentifier:", "L", -1), ("walkString:", "L", -1), ("Dot", "L", -1), ("Equals", "L", -1), ("RightArrow", "L", -1), ("OpenCurly", "L", -1), ("walkSymbol:", "L", -1), ("walkCharacter:", "L", -1), ("walkInteger:", "L", -1), ("CloseSquare", "L", -1), ("OpenSquare", "L", -1), ("Or", "L", -1), ("OpenRound", "L", -1), ("Star", "L", -1), ("QuestionMark", "L", -1), ("Plus", "L", -1), ("Minus", "L", -1), ("And", "L", -1), ("CloseRound", "L", -1), ("CloseCurly", "L", -1), ("FatRightArrow", "L", -1)],
        ["ReadaheadTable", 23, ("walkString:", "RSN", 21), ("Name", "L", 23), ("walkIdentifier:", "RSN", 22), ("Dot", "RS", 33)],
        ["ReadaheadTable", 24, ("Name", "L", 34), ("walkIdentifier:", "RSN", 22), ("walkString:", "RSN", 21)],
        ["ReadaheadTable", 25, ("defaults", "L", 35)],
        ["ReadaheadTable", 26, ("defaults", "L", 36)],
        ["ReadaheadTable", 27, ("Dot", "RS", 37)],
        ["ReadaheadTable", 28, ("keywords", "L", 9), ("attribute", "RS", 38), ("output", "L", 11), ("Defaults", "L", 12), ("optimize", "L", 13), ("Macro", "L", 16), ("Rules", "RSN", 15), ("Production", "L", 14)],
        ["ReadaheadTable", 29, ("Dot", "RS", 39)],
        ["ReadaheadTable", 30, ("RightParts", "RSN", 40), ("RightPart", "L", 41)],
        ["ReadaheadTable", 31, ("Equals", "L", 42)],
        ["ReadaheadTable", 32, ("-|", "L", -1)],
        ["ReadaheadTable", 33, ("attribute", "L", -1), ("keywords", "L", -1), ("output", "L", -1), ("optimize", "L", -1), ("walkIdentifier:", "L", -1), ("walkString:", "L", -1)],
        ["ReadaheadTable", 34, ("walkString:", "RSN", 21), ("Name", "L", 34), ("walkIdentifier:", "RSN", 22), ("Dot", "RS", 44)],
        ["ReadaheadTable", 35, ("walkString:", "RSN", 21), ("walkIdentifier:", "RSN", 22), ("Name", "L", 45)],
        ["ReadaheadTable", 36, ("walkString:", "RSN", 21), ("walkIdentifier:", "RSN", 22), ("Name", "L", 46)],
        ["ReadaheadTable", 37, ("attribute", "L", -1), ("keywords", "L", -1), ("output", "L", -1), ("optimize", "L", -1), ("walkIdentifier:", "L", -1), ("walkString:", "L", -1)],
        ["ReadaheadTable", 38, ("defaults", "L", 24), ("nonterminal", "RS", 25), ("terminal", "RS", 26)],
        ["ReadaheadTable", 39, ("attribute", "L", -1), ("keywords", "L", -1), ("output", "L", -1), ("optimize", "L", -1), ("walkIdentifier:", "L", -1), ("walkString:", "L", -1)],
        ["ReadaheadTable", 40, ("Dot", "RS", 49)],
        ["ReadaheadTable", 41, ("RightArrow", "L", 50), ("RightPart", "L", 41), ("Dot", "L", -1)],
        ["ReadaheadTable", 42, ("Expression", "RSN", 52), ("AndExpression", "RSN", 53)],
        ["ReadaheadTable", 43, ("attribute", "L", -1), ("keywords", "L", -1), ("output", "L", -1), ("optimize", "L", -1), ("walkIdentifier:", "L", -1), ("walkString:", "L", -1)],
        ["ReadaheadTable", 44, ("attribute", "L", -1), ("keywords", "L", -1), ("output", "L", -1), ("optimize", "L", -1), ("walkIdentifier:", "L", -1), ("walkString:", "L", -1)],
        ["ReadaheadTable", 45, ("walkString:", "RSN", 21), ("Name", "L", 45), ("walkIdentifier:", "RSN", 22), ("Dot", "RS", 55)],
        ["ReadaheadTable", 46, ("Name", "L", 46), ("walkString:", "RSN", 21), ("walkIdentifier:", "RSN", 22), ("Dot", "RS", 56)],
        ["ReadaheadTable", 47, ("attribute", "L", -1), ("keywords", "L", -1), ("output", "L", -1), ("optimize", "L", -1), ("walkIdentifier:", "L", -1), ("walkString:", "L", -1)],
        ["ReadaheadTable", 48, ("attribute", "L", -1), ("keywords", "L", -1), ("output", "L", -1), ("optimize", "L", -1), ("walkIdentifier:", "L", -1), ("walkString:", "L", -1)],
        ["ReadaheadTable", 49, ("walkIdentifier:", "L", -1), ("walkString:", "L", -1), ("-|", "L", -1)],
        ["ReadaheadTable", 50, ("Expression", "RSN", 58), ("AndExpression", "RSN", 59)],
        ["ReadaheadTable", 51, ("Dot", "L", -1)],
        ["ReadaheadTable", 52, ("Dot", "RS", 60)],
        ["ReadaheadTable", 53, ("Minus", "L", 61), ("CloseRound", "L", -1), ("CloseCurly", "L", -1), ("FatRightArrow", "L", -1), ("Dot", "L", -1), ("RightArrow", "L", -1)],
        ["ReadaheadTable", 54, ("attribute", "L", -1), ("keywords", "L", -1), ("output", "L", -1), ("optimize", "L", -1), ("walkIdentifier:", "L", -1), ("walkString:", "L", -1)],
        ["ReadaheadTable", 55, ("attribute", "L", -1), ("keywords", "L", -1), ("output", "L", -1), ("optimize", "L", -1), ("walkIdentifier:", "L", -1), ("walkString:", "L", -1)],
        ["ReadaheadTable", 56, ("attribute", "L", -1), ("keywords", "L", -1), ("output", "L", -1), ("optimize", "L", -1), ("walkIdentifier:", "L", -1), ("walkString:", "L", -1)],
        ["ReadaheadTable", 57, ("walkIdentifier:", "L", -1), ("walkString:", "L", -1), ("-|", "L", -1)],
        ["ReadaheadTable", 58, ("FatRightArrow", "L", 64), ("RightArrow", "L", -1), ("Dot", "L", -1)],
        ["ReadaheadTable", 59, ("Minus", "L", 61), ("CloseRound", "L", -1), ("CloseCurly", "L", -1), ("FatRightArrow", "L", -1), ("Dot", "L", -1), ("RightArrow", "L", -1)],
        ["ReadaheadTable", 60, ("walkIdentifier:", "L", -1), ("walkString:", "L", -1), ("-|", "L", -1)],
        ["ReadaheadTable", 61, ("AndExpression", "RSN", 66), ("Alternation", "RSN", 67)],
        ["ReadaheadTable", 62, ("attribute", "L", -1), ("keywords", "L", -1), ("output", "L", -1), ("optimize", "L", -1), ("walkIdentifier:", "L", -1), ("walkString:", "L", -1)],
        ["ReadaheadTable", 63, ("attribute", "L", -1), ("keywords", "L", -1), ("output", "L", -1), ("optimize", "L", -1), ("walkIdentifier:", "L", -1), ("walkString:", "L", -1)],
        ["ReadaheadTable", 64, ("TreeBuildingOptions", "RSN", 68), ("walkInteger:", "RSN", 69), ("Name", "RSN", 70), ("Plus", "RS", 71), ("SemanticAction", "RSN", 72), ("Minus", "RS", 73)],
        ["ReadaheadTable", 65, ("walkIdentifier:", "L", -1), ("walkString:", "L", -1), ("-|", "L", -1)],
        ["ReadaheadTable", 66, ("CloseRound", "L", -1), ("CloseCurly", "L", -1), ("FatRightArrow", "L", -1), ("Dot", "L", -1), ("RightArrow", "L", -1)],
        ["ReadaheadTable", 67, ("And", "L", 75), ("Minus", "L", -1), ("CloseRound", "L", -1), ("CloseCurly", "L", -1), ("FatRightArrow", "L", -1), ("Dot", "L", -1), ("RightArrow", "L", -1)],
        ["ReadaheadTable", 68, ("RightArrow", "L", -1), ("Dot", "L", -1)],
        ["ReadaheadTable", 69, ("RightArrow", "L", -1), ("Dot", "L", -1)],
        ["ReadaheadTable", 70, ("RightArrow", "L", -1), ("Dot", "L", -1)],
        ["ReadaheadTable", 71, ("walkInteger:", "RSN", 69)],
        ["ReadaheadTable", 72, ("RightArrow", "L", -1), ("Dot", "L", -1)],
        ["ReadaheadTable", 73, ("walkInteger:", "RSN", 80)],
        ["ReadaheadTable", 74, ("CloseRound", "L", -1), ("CloseCurly", "L", -1), ("FatRightArrow", "L", -1), ("Dot", "L", -1), ("RightArrow", "L", -1)],
        ["ReadaheadTable", 75, ("Concatenation", "RSN", 81), ("Alternation", "RSN", 82), ("Minus", "L", -1), ("And", "L", -1), ("CloseRound", "L", -1), ("CloseCurly", "L", -1), ("FatRightArrow", "L", -1), ("Dot", "L", -1), ("RightArrow", "L", -1)],
        ["ReadaheadTable", 76, ("RightArrow", "L", -1), ("Dot", "L", -1)],
        ["ReadaheadTable", 77, ("RightArrow", "L", -1), ("Dot", "L", -1)],
        ["ReadaheadTable", 78, ("RightArrow", "L", -1), ("Dot", "L", -1)],
        ["ReadaheadTable", 79, ("RightArrow", "L", -1), ("Dot", "L", -1)],
        ["ReadaheadTable", 80, ("RightArrow", "L", -1), ("Dot", "L", -1)],
        ["ReadaheadTable", 81, ("Or", "L", 85), ("Minus", "L", -1), ("And", "L", -1), ("CloseRound", "L", -1), ("CloseCurly", "L", -1), ("FatRightArrow", "L", -1), ("Dot", "L", -1), ("RightArrow", "L", -1)],
        ["ReadaheadTable", 82, ("Minus", "L", -1), ("CloseRound", "L", -1), ("CloseCurly", "L", -1), ("FatRightArrow", "L", -1), ("Dot", "L", -1), ("RightArrow", "L", -1)],
        ["ReadaheadTable", 83, ("Minus", "L", -1), ("And", "L", -1), ("CloseRound", "L", -1), ("CloseCurly", "L", -1), ("FatRightArrow", "L", -1), ("Dot", "L", -1), ("RightArrow", "L", -1)],
        ["ReadaheadTable", 84, ("RightArrow", "L", -1), ("Dot", "L", -1)],
        ["ReadaheadTable", 85, ("Concatenation", "RSN", 87), ("RepetitionOption", "RSN", 88)],
        ["ReadaheadTable", 86, ("Minus", "L", -1), ("CloseRound", "L", -1), ("CloseCurly", "L", -1), ("FatRightArrow", "L", -1), ("Dot", "L", -1), ("RightArrow", "L", -1)],
        ["ReadaheadTable", 87, ("Or", "L", 85), ("Minus", "L", -1), ("And", "L", -1), ("CloseRound", "L", -1), ("CloseCurly", "L", -1), ("FatRightArrow", "L", -1), ("Dot", "L", -1), ("RightArrow", "L", -1)],
        ["ReadaheadTable", 88, ("Primary", "RSN", 90), ("RepetitionOption", "L", 91), ("Or", "L", -1), ("Minus", "L", -1), ("And", "L", -1), ("CloseRound", "L", -1), ("CloseCurly", "L", -1), ("FatRightArrow", "L", -1), ("Dot", "L", -1), ("RightArrow", "L", -1)],
        ["ReadaheadTable", 89, ("Minus", "L", -1), ("And", "L", -1), ("CloseRound", "L", -1), ("CloseCurly", "L", -1), ("FatRightArrow", "L", -1), ("Dot", "L", -1), ("RightArrow", "L", -1)],
        ["ReadaheadTable", 90, ("Star", "RS", 92), ("QuestionMark", "RS", 93), ("Plus", "RS", 94), ("Or", "L", -1), ("OpenRound", "L", -1), ("OpenCurly", "L", -1), ("walkSymbol:", "L", -1), ("walkIdentifier:", "L", -1), ("walkString:", "L", -1), ("walkCharacter:", "L", -1), ("walkInteger:", "L", -1), ("Minus", "L", -1), ("And", "L", -1), ("CloseRound", "L", -1), ("CloseCurly", "L", -1), ("FatRightArrow", "L", -1), ("Dot", "L", -1), ("RightArrow", "L", -1)],
        ["ReadaheadTable", 91, ("Primary", "RSN", 95), ("RepetitionOption", "L", 91), ("Or", "L", -1), ("Minus", "L", -1), ("And", "L", -1), ("CloseRound", "L", -1), ("CloseCurly", "L", -1), ("FatRightArrow", "L", -1), ("Dot", "L", -1), ("RightArrow", "L", -1)],
        ["ReadaheadTable", 92, ("Or", "L", -1), ("OpenRound", "L", -1), ("OpenCurly", "L", -1), ("walkSymbol:", "L", -1), ("walkIdentifier:", "L", -1), ("walkString:", "L", -1), ("walkCharacter:", "L", -1), ("walkInteger:", "L", -1), ("Minus", "L", -1), ("And", "L", -1), ("CloseRound", "L", -1), ("CloseCurly", "L", -1), ("FatRightArrow", "L", -1), ("Dot", "L", -1), ("RightArrow", "L", -1)],
        ["ReadaheadTable", 93, ("Or", "L", -1), ("OpenRound", "L", -1), ("OpenCurly", "L", -1), ("walkSymbol:", "L", -1), ("walkIdentifier:", "L", -1), ("walkString:", "L", -1), ("walkCharacter:", "L", -1), ("walkInteger:", "L", -1), ("Minus", "L", -1), ("And", "L", -1), ("CloseRound", "L", -1), ("CloseCurly", "L", -1), ("FatRightArrow", "L", -1), ("Dot", "L", -1), ("RightArrow", "L", -1)],
        ["ReadaheadTable", 94, ("Or", "L", -1), ("OpenRound", "L", -1), ("OpenCurly", "L", -1), ("walkSymbol:", "L", -1), ("walkIdentifier:", "L", -1), ("walkString:", "L", -1), ("walkCharacter:", "L", -1), ("walkInteger:", "L", -1), ("Minus", "L", -1), ("And", "L", -1), ("CloseRound", "L", -1), ("CloseCurly", "L", -1), ("FatRightArrow", "L", -1), ("Dot", "L", -1), ("RightArrow", "L", -1)],
        ["ReadaheadTable", 95, ("Star", "RS", 92), ("QuestionMark", "RS", 93), ("Plus", "RS", 94), ("Or", "L", -1), ("OpenRound", "L", -1), ("OpenCurly", "L", -1), ("walkSymbol:", "L", -1), ("walkIdentifier:", "L", -1), ("walkString:", "L", -1), ("walkCharacter:", "L", -1), ("walkInteger:", "L", -1), ("Minus", "L", -1), ("And", "L", -1), ("CloseRound", "L", -1), ("CloseCurly", "L", -1), ("FatRightArrow", "L", -1), ("Dot", "L", -1), ("RightArrow", "L", -1)],
        ["ReadaheadTable", 96, ("Or", "L", -1), ("Minus", "L", -1), ("And", "L", -1), ("CloseRound", "L", -1), ("CloseCurly", "L", -1), ("FatRightArrow", "L", -1), ("Dot", "L", -1), ("RightArrow", "L", -1)],
        ["ReadaheadTable", 97, ("Or", "L", -1), ("OpenRound", "L", -1), ("OpenCurly", "L", -1), ("walkSymbol:", "L", -1), ("walkIdentifier:", "L", -1), ("walkString:", "L", -1), ("walkCharacter:", "L", -1), ("walkInteger:", "L", -1), ("Minus", "L", -1), ("And", "L", -1), ("CloseRound", "L", -1), ("CloseCurly", "L", -1), ("FatRightArrow", "L", -1), ("Dot", "L", -1), ("RightArrow", "L", -1)],
        ["ReadaheadTable", 98, ("Or", "L", -1), ("OpenRound", "L", -1), ("OpenCurly", "L", -1), ("walkSymbol:", "L", -1), ("walkIdentifier:", "L", -1), ("walkString:", "L", -1), ("walkCharacter:", "L", -1), ("walkInteger:", "L", -1), ("Minus", "L", -1), ("And", "L", -1), ("CloseRound", "L", -1), ("CloseCurly", "L", -1), ("FatRightArrow", "L", -1), ("Dot", "L", -1), ("RightArrow", "L", -1)],
        ["ReadaheadTable", 99, ("Or", "L", -1), ("OpenRound", "L", -1), ("OpenCurly", "L", -1), ("walkSymbol:", "L", -1), ("walkIdentifier:", "L", -1), ("walkString:", "L", -1), ("walkCharacter:", "L", -1), ("walkInteger:", "L", -1), ("Minus", "L", -1), ("And", "L", -1), ("CloseRound", "L", -1), ("CloseCurly", "L", -1), ("FatRightArrow", "L", -1), ("Dot", "L", -1), ("RightArrow", "L", -1)],
        ["ReadbackTable", 100, (("scanner", 5), "RS", 137)],
        ["ReadbackTable", 101, (("parser", 6), "RS", 138)],
        ["ReadbackTable", 102, (("superScanner", 7), "RS", 139)],
        ["ReadbackTable", 103, (("scanner", 8), "RS", 140)],
        ["ReadbackTable", 104, (("walkString:", 21), "RSN", 141)],
        ["ReadbackTable", 105, (("walkIdentifier:", 22), "RSN", 142)],
        ["ReadbackTable", 106, (("Production", 14), "L", 143), (("Macro", 16), "L", 144)],
        ["ReadbackTable", 107, (("Dot", 33), "RS", 145)],
        ["ReadbackTable", 108, (("Dot", 37), "RS", 146)],
        ["ReadbackTable", 109, (("Dot", 39), "RS", 147)],
        ["ReadbackTable", 110, (("RightPart", 41), "L", 148)],
        ["ReadbackTable", 111, (("AndExpression", 53), "RSN", 149)],
        ["ReadbackTable", 112, (("Dot", 44), "RS", 150)],
        ["ReadbackTable", 113, (("Dot", 49), "RS", 151)],
        ["ReadbackTable", 114, (("Expression", 58), "RSN", 152)],
        ["ReadbackTable", 115, (("AndExpression", 59), "RSN", 153)],
        ["ReadbackTable", 116, (("Dot", 55), "RS", 154)],
        ["ReadbackTable", 117, (("Dot", 56), "RS", 155)],
        ["ReadbackTable", 118, (("Dot", 60), "RS", 156)],
        ["ReadbackTable", 119, (("Alternation", 67), "RSN", 157)],
        ["ReadbackTable", 120, (("AndExpression", 66), "RSN", 158)],
        ["ReadbackTable", 121, (("TreeBuildingOptions", 68), "RSN", 159)],
        ["ReadbackTable", 122, (("walkInteger:", 69), "RSN", 160)],
        ["ReadbackTable", 123, (("Name", 70), "RSN", 161)],
        ["ReadbackTable", 124, (("SemanticAction", 72), "RSN", 162)],
        ["ReadbackTable", 125, (("Concatenation", 81), "RSN", 163)],
        ["ReadbackTable", 126, (("And", 75), "L", 257)],
        ["ReadbackTable", 127, (("walkInteger:", 80), "RSN", 164)],
        ["ReadbackTable", 128, (("Alternation", 82), "RSN", 165)],
        ["ReadbackTable", 129, (("RepetitionOption", 88), "RSN", 166)],
        ["ReadbackTable", 130, (("Concatenation", 87), "RSN", 167)],
        ["ReadbackTable", 131, (("Primary", 90), "RSN", 168)],
        ["ReadbackTable", 132, (("Primary", 95), "RSN", 169)],
        ["ReadbackTable", 133, (("RepetitionOption", 91), "L", 170)],
        ["ReadbackTable", 134, (("Star", 92), "RS", 171)],
        ["ReadbackTable", 135, (("QuestionMark", 93), "RS", 172)],
        ["ReadbackTable", 136, (("Plus", 94), "RS", 173)],
        ["ReadbackTable", 137, (("|-", 2), "L", 272)],
        ["ReadbackTable", 138, (("|-", 2), "L", 272)],
        ["ReadbackTable", 139, (("|-", 2), "L", 272)],
        ["ReadbackTable", 140, (("super", 3), "RS", 174)],
        ["ReadbackTable", 141, (("defaults", 36), "L", 260), (("keywords", 9), "L", 260), (("defaults", 24), "L", 260), (("defaults", 35), "L", 260), (("optimize", 13), "L", 260), (("Name", 23), "L", 260), (("Name", 45), "L", 260), (("output", 11), "L", 260), (("Name", 46), "L", 260), (("Name", 34), "L", 260)],
        ["ReadbackTable", 142, (("Name", 46), "L", 260), (("Name", 23), "L", 260), (("Name", 45), "L", 260), (("defaults", 36), "L", 260), (("defaults", 24), "L", 260), (("keywords", 9), "L", 260), (("optimize", 13), "L", 260), (("output", 11), "L", 260), (("Name", 34), "L", 260), (("defaults", 35), "L", 260)],
        ["ReadbackTable", 143, (("Production", 14), "L", 175), (("Macro", 16), "L", 176), (("GrammarType", 4), "L", 256), (("Defaults", 12), "L", 256)],
        ["ReadbackTable", 144, (("Production", 14), "L", 175), (("Macro", 16), "L", 176), (("GrammarType", 4), "L", 256), (("Defaults", 12), "L", 256)],
        ["ReadbackTable", 145, (("Name", 23), "L", 177)],
        ["ReadbackTable", 146, (("Name", 27), "RSN", 178)],
        ["ReadbackTable", 147, (("Name", 29), "RSN", 179)],
        ["ReadbackTable", 148, (("RightPart", 41), "L", 180), (("LeftPart", 30), "L", 259)],
        ["ReadbackTable", 149, (("Equals", 42), "L", 275)],
        ["ReadbackTable", 150, (("Name", 34), "L", 181)],
        ["ReadbackTable", 151, (("RightParts", 40), "RSN", 182)],
        ["ReadbackTable", 152, (("RightArrow", 50), "L", 183)],
        ["ReadbackTable", 153, (("RightArrow", 50), "L", 275)],
        ["ReadbackTable", 154, (("Name", 45), "L", 184)],
        ["ReadbackTable", 155, (("Name", 46), "L", 185)],
        ["ReadbackTable", 156, (("Expression", 52), "RSN", 186)],
        ["ReadbackTable", 157, (("Minus", 61), "L", 268)],
        ["ReadbackTable", 158, (("Minus", 61), "L", 187)],
        ["ReadbackTable", 159, (("FatRightArrow", 64), "L", 188)],
        ["ReadbackTable", 160, (("Plus", 71), "RS", 189), (("FatRightArrow", 64), "L", 269)],
        ["ReadbackTable", 161, (("FatRightArrow", 64), "L", 269)],
        ["ReadbackTable", 162, (("FatRightArrow", 64), "L", 269)],
        ["ReadbackTable", 163, (("And", 75), "L", 257)],
        ["ReadbackTable", 164, (("Minus", 73), "RS", 190)],
        ["ReadbackTable", 165, (("And", 75), "L", 191)],
        ["ReadbackTable", 166, (("Or", 85), "L", 266)],
        ["ReadbackTable", 167, (("Or", 85), "L", 192), (("Or", 85), "L", 193)],
        ["ReadbackTable", 168, (("RepetitionOption", 88), "L", 273)],
        ["ReadbackTable", 169, (("RepetitionOption", 91), "L", 273)],
        ["ReadbackTable", 170, (("RepetitionOption", 88), "L", 194), (("RepetitionOption", 91), "L", 195), (("RepetitionOption", 91), "L", 196)],
        ["ReadbackTable", 171, (("Primary", 90), "RSN", 197), (("Primary", 95), "RSN", 198)],
        ["ReadbackTable", 172, (("Primary", 90), "RSN", 199), (("Primary", 95), "RSN", 200)],
        ["ReadbackTable", 173, (("Primary", 90), "RSN", 201), (("Primary", 95), "RSN", 202)],
        ["ReadbackTable", 174, (("|-", 2), "L", 272)],
        ["ReadbackTable", 175, (("Production", 14), "L", 175), (("Macro", 16), "L", 176), (("GrammarType", 4), "L", 256), (("Defaults", 12), "L", 256)],
        ["ReadbackTable", 176, (("Production", 14), "L", 175), (("Macro", 16), "L", 176), (("GrammarType", 4), "L", 256), (("Defaults", 12), "L", 256)],
        ["ReadbackTable", 177, (("Name", 23), "L", 177), (("keywords", 9), "L", 203)],
        ["ReadbackTable", 178, (("output", 11), "L", 204)],
        ["ReadbackTable", 179, (("optimize", 13), "L", 205)],
        ["ReadbackTable", 180, (("RightPart", 41), "L", 148), (("LeftPart", 30), "L", 259)],
        ["ReadbackTable", 181, (("Name", 34), "L", 181), (("defaults", 24), "L", 206)],
        ["ReadbackTable", 182, (("LeftPart", 30), "L", 207)],
        ["ReadbackTable", 183, (("RightPart", 41), "L", 255)],
        ["ReadbackTable", 184, (("Name", 45), "L", 184), (("defaults", 35), "L", 208)],
        ["ReadbackTable", 185, (("defaults", 36), "L", 209), (("Name", 46), "L", 185)],
        ["ReadbackTable", 186, (("Equals", 42), "L", 210)],
        ["ReadbackTable", 187, (("AndExpression", 59), "RSN", 211), (("AndExpression", 53), "RSN", 212)],
        ["ReadbackTable", 188, (("Expression", 58), "RSN", 213)],
        ["ReadbackTable", 189, (("FatRightArrow", 64), "L", 269)],
        ["ReadbackTable", 190, (("FatRightArrow", 64), "L", 269)],
        ["ReadbackTable", 191, (("Alternation", 67), "RSN", 214)],
        ["ReadbackTable", 192, (("Concatenation", 87), "RSN", 167)],
        ["ReadbackTable", 193, (("Concatenation", 81), "RSN", 215)],
        ["ReadbackTable", 194, (("Or", 85), "L", 266)],
        ["ReadbackTable", 195, (("RepetitionOption", 88), "L", 194)],
        ["ReadbackTable", 196, (("RepetitionOption", 91), "L", 195), (("RepetitionOption", 91), "L", 196)],
        ["ReadbackTable", 197, (("RepetitionOption", 88), "L", 273)],
        ["ReadbackTable", 198, (("RepetitionOption", 91), "L", 273)],
        ["ReadbackTable", 199, (("RepetitionOption", 88), "L", 273)],
        ["ReadbackTable", 200, (("RepetitionOption", 91), "L", 273)],
        ["ReadbackTable", 201, (("RepetitionOption", 88), "L", 273)],
        ["ReadbackTable", 202, (("RepetitionOption", 91), "L", 273)],
        ["ReadbackTable", 203, (("GrammarType", 4), "L", 262), (("Defaults", 12), "L", 262)],
        ["ReadbackTable", 204, (("GrammarType", 4), "L", 262), (("Defaults", 12), "L", 262)],
        ["ReadbackTable", 205, (("GrammarType", 4), "L", 262), (("Defaults", 12), "L", 262)],
        ["ReadbackTable", 206, (("attribute", 10), "RS", 216), (("attribute", 38), "RS", 217)],
        ["ReadbackTable", 207, (("Production", 14), "L", 276), (("Macro", 16), "L", 276)],
        ["ReadbackTable", 208, (("nonterminal", 25), "RS", 218)],
        ["ReadbackTable", 209, (("terminal", 26), "RS", 219)],
        ["ReadbackTable", 210, (("Name", 31), "RSN", 220)],
        ["ReadbackTable", 211, (("RightArrow", 50), "L", 275)],
        ["ReadbackTable", 212, (("Equals", 42), "L", 275)],
        ["ReadbackTable", 213, (("RightArrow", 50), "L", 221)],
        ["ReadbackTable", 214, (("Minus", 61), "L", 268)],
        ["ReadbackTable", 215, (("And", 75), "L", 257)],
        ["ReadbackTable", 216, (("GrammarType", 4), "L", 262)],
        ["ReadbackTable", 217, (("Defaults", 12), "L", 262)],
        ["ReadbackTable", 218, (("attribute", 10), "RS", 222), (("attribute", 38), "RS", 223)],
        ["ReadbackTable", 219, (("attribute", 10), "RS", 224), (("attribute", 38), "RS", 225)],
        ["ReadbackTable", 220, (("Production", 14), "L", 261), (("Macro", 16), "L", 261)],
        ["ReadbackTable", 221, (("RightPart", 41), "L", 255)],
        ["ReadbackTable", 222, (("GrammarType", 4), "L", 262)],
        ["ReadbackTable", 223, (("Defaults", 12), "L", 262)],
        ["ReadbackTable", 224, (("GrammarType", 4), "L", 262)],
        ["ReadbackTable", 225, (("Defaults", 12), "L", 262)],
        ["ReduceTable", 255, "RightPart", (30, "RSN", 41), (41, "RSN", 41)],
        ["ReduceTable", 256, "Rules", (4, "RSN", 15), (12, "RSN", 15), (28, "RSN", 15)],
        ["ReduceTable", 257, "Alternation", (61, "RSN", 67), (75, "RSN", 82)],
        ["ReduceTable", 258, "LeftPart", (14, "RSN", 30), (16, "RSN", 30)],
        ["ReduceTable", 259, "RightParts", (30, "RSN", 40)],
        ["ReduceTable", 260, "Name", (9, "RSN", 23), (11, "RSN", 27), (13, "RSN", 29), (14, "RSN", 31), (16, "RSN", 31), (23, "RSN", 23), (24, "RSN", 34), (34, "RSN", 34), (35, "RSN", 45), (36, "RSN", 46), (45, "RSN", 45), (46, "RSN", 46), (64, "RSN", 70)],
        ["ReduceTable", 261, "Macro", (4, "RSN", 16), (14, "RSN", 16), (16, "RSN", 16), (28, "RSN", 16)],
        ["ReduceTable", 262, "Defaults", (4, "RSN", 12), (12, "RSN", 12), (28, "RSN", 12)],
        ["ReduceTable", 263, "SemanticActionParameter", ],
        ["ReduceTable", 264, "Grammar", ],
        ["ReduceTable", 265, "Primary", (88, "RSN", 90), (91, "RSN", 95)],
        ["ReduceTable", 266, "Concatenation", (75, "RSN", 81), (85, "RSN", 87)],
        ["ReduceTable", 267, "Secondary", ],
        ["ReduceTable", 268, "AndExpression", (42, "RSN", 53), (50, "RSN", 59), (61, "RSN", 66)],
        ["ReduceTable", 269, "TreeBuildingOptions", (64, "RSN", 68)],
        ["ReduceTable", 270, "Byte", ],
        ["ReduceTable", 271, "Attribute", ],
        ["ReduceTable", 272, "GrammarType", (2, "RSN", 4)],
        ["ReduceTable", 273, "RepetitionOption", (85, "RSN", 88), (88, "RSN", 91), (91, "RSN", 91)],
        ["ReduceTable", 274, "SemanticAction", (64, "RSN", 72)],
        ["ReduceTable", 275, "Expression", (42, "RSN", 52), (50, "RSN", 58)],
        ["ReduceTable", 276, "Production", (4, "RSN", 14), (14, "RSN", 14), (16, "RSN", 14), (28, "RSN", 14)],
        ["SemanticTable", 226, "#processTypeNow:", ["scanner"], 17],
        ["SemanticTable", 227, "#processTypeNow:", ["parser"], 18],
        ["SemanticTable", 228, "#processTypeNow:", ["superScanner"], 19],
        ["SemanticTable", 229, "#processTypeNow:", ["superScanner"], 20],
        ["SemanticTable", 230, "#processAndDiscardDefaultsNow", [], 28],
        ["SemanticTable", 231, "#buildTree", ["walkGrammar"], 32],
        ["SemanticTable", 232, "#buildTree", ["walkGrammar"], 32],
        ["SemanticTable", 233, "#buildTree", ["walkKeywords"], 43],
        ["SemanticTable", 234, "#buildTree", ["walkOutput"], 47],
        ["SemanticTable", 235, "#buildTree", ["walkOptimize"], 48],
        ["SemanticTable", 236, "#buildTree", ["walkOr"], 51],
        ["SemanticTable", 237, "#buildTree", ["walkAttributeDefaults"], 54],
        ["SemanticTable", 238, "#buildTree", ["walkProduction"], 57],
        ["SemanticTable", 239, "#buildTree", ["walkAttributeNonterminalDefaults"], 62],
        ["SemanticTable", 240, "#buildTree", ["walkAttributeTerminalDefaults"], 63],
        ["SemanticTable", 241, "#buildTree", ["walkMacro"], 65],
        ["SemanticTable", 242, "#buildTree", ["walkMinus"], 74],
        ["SemanticTable", 243, "#buildTree", ["walkConcatenation"], 76],
        ["SemanticTable", 244, "#buildTree", ["walkBuildTreeFromLeftIndex"], 77],
        ["SemanticTable", 245, "#buildTree", ["walkBuildTreeOrTokenFromName"], 78],
        ["SemanticTable", 246, "#buildTree", ["walkTreeBuildingSemanticAction"], 79],
        ["SemanticTable", 247, "#buildTree", ["walkEpsilon"], 83],
        ["SemanticTable", 248, "#buildTree", ["walkBuildTreeFromRightIndex"], 84],
        ["SemanticTable", 249, "#buildTree", ["walkAnd"], 86],
        ["SemanticTable", 250, "#buildTree", ["walkOr"], 89],
        ["SemanticTable", 251, "#buildTree", ["walkConcatenation"], 96],
        ["SemanticTable", 252, "#buildTree", ["walkStar"], 97],
        ["SemanticTable", 253, "#buildTree", ["walkQuestionMark"], 98],
        ["SemanticTable", 254, "#buildTree", ["walkPlus"], 99],
        ["AcceptTable", 277]]
}
