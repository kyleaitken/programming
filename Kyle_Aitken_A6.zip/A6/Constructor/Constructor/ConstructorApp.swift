//
//  ConstructorApp.swift
//  Constructor
//
//  Created by Kyle Aitken on 2025-02-05.
//

import SwiftUI

@main
struct ConstructorApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
